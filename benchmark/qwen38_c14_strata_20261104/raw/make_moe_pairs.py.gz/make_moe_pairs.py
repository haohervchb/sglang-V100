from pathlib import Path
root=Path('/home/rah/qwen38-runs/20261104-c14-strata-round');src=Path('/home/rah/sglang-V100/python/sglang/jit_kernel/csrc/sm70_nvfp4_moe_decode.cu').read_text()
a=src.index('template <bool VectorScales>\n__global__ void __launch_bounds__(kThreads, 2)\ngate_up_partial_kernel');b=src.index('\n__global__ void',src.index('_partial_kernel(',a));g=src[a:b]
g=g.replace('int num_routes,\n                       float*','int num_routes, const int* pairs, int pair_count,\n                       float*')
g=g.replace('num_routes * kSplitK * kQwords','pair_count * kSplitK * kQwords')
g=g.replace('const int route = split_route / kSplitK;','const int pair = split_route / kSplitK;\n  const int route = pairs[pair*2], route1 = pairs[pair*2+1];')
g=g.replace('const int token = route / kTopK;','const int token = route / kTopK, token1 = route1 / kTopK;')
needle='''  const int group_begin = split * kGroupsPerSplit;''';g=g.replace(needle,'''  __half2 accum1[4] = {__float2half2_rn(0.f),__float2half2_rn(0.f),__float2half2_rn(0.f),__float2half2_rn(0.f)};
'''+needle)
g=g.replace('''      const int qword_in_tile = qword & 7;''','''      const __half2 x1 = route1 >= 0 ? __halves2half2(input[token1*kHidden+k],input[token1*kHidden+k]) : __float2half2_rn(0.f);
      const int qword_in_tile = qword & 7;''')
g=g.replace('accum[p] = __hfma2(x, __hmul2(scale[p], value[p]), accum[p]);','accum[p] = __hfma2(x, __hmul2(scale[p], value[p]), accum[p]);\n        if(route1>=0)accum1[p]=__hfma2(x1,__hmul2(scale[p],value[p]),accum1[p]);')
g=g.replace('''    out[2 * p + 1] = __half2float(accum[p].y);''','''    out[2 * p + 1] = __half2float(accum[p].y);
    if(route1>=0){float* other=partials+((split*num_routes+route1)*kGateUp+n_base);other[2*p]=__half2float(accum1[p].x);other[2*p+1]=__half2float(accum1[p].y);}''')
src=src[:a]+g+src[b:]
a=src.index('template <bool VectorScales>\n__global__ void __launch_bounds__(kThreads, 2)\ndown_partial_kernel');b=src.index('\n__global__ void',src.index('_partial_kernel(',a));d=src[a:b]
d=d.replace('int num_routes,\n                    float*','int num_routes, const int* pairs, int pair_count,\n                    float*').replace('num_routes * kDownSplitK * kQwords','pair_count * kDownSplitK * kQwords')
d=d.replace('const int route = split_route / kDownSplitK;','const int pair = split_route / kDownSplitK;\n  const int route = pairs[pair*2], route1=pairs[pair*2+1];')
d=d.replace('''      out[p] = 0.0f;''','''      out[p] = 0.0f;
      if(route1>=0)partials[(route1*kDownSplitK+split)*kHidden+n_base+p]=0.f;''')
d=d.replace(needle,'''  __half2 accum1[4] = {__float2half2_rn(0.f),__float2half2_rn(0.f),__float2half2_rn(0.f),__float2half2_rn(0.f)};
'''+needle)
d=d.replace('''      const int group_n_tile = qword >> 5;''','''      const __half2 x1 = route1>=0 ? __halves2half2(activated[route1*kIntermediate+k],activated[route1*kIntermediate+k]) : __float2half2_rn(0.f);
      const int group_n_tile = qword >> 5;''')
d=d.replace('accum[p] = __hfma2(x, __hmul2(scale[p], value[p]), accum[p]);','accum[p] = __hfma2(x, __hmul2(scale[p], value[p]), accum[p]);\n        if(route1>=0)accum1[p]=__hfma2(x1,__hmul2(scale[p],value[p]),accum1[p]);')
d=d.replace('''    out[2 * p + 1] = __half2float(accum[p].y) * multiplier;''','''    out[2 * p + 1] = __half2float(accum[p].y) * multiplier;
    if(route1>=0){float* other=partials+(route1*kDownSplitK+split)*kHidden+n_base;float mult=global_scales[expert]*kMarlinScaleCompensation*topk_weights[route1];other[2*p]=__half2float(accum1[p].x)*mult;other[2*p+1]=__half2float(accum1[p].y)*mult;}''')
src=src[:a]+d+src[b:]
src=src.replace('torch::Tensor down_partials, torch::Tensor output) {','torch::Tensor down_partials, torch::Tensor output, torch::Tensor pairs) {')
src=src.replace('const int gate_up_work = num_routes * kSplitK', 'const int pair_count = pairs.size(0);\n  const int gate_up_work = pair_count * kSplitK')
src=src.replace('topk_ids.data_ptr<int>(), num_routes, gate_up_partials.data_ptr<float>());','topk_ids.data_ptr<int>(), num_routes, pairs.data_ptr<int>(), pair_count, gate_up_partials.data_ptr<float>());')
src=src.replace('const int down_work = num_routes * kDownSplitK','const int down_work = pair_count * kDownSplitK')
src=src.replace('topk_weights.data_ptr<float>(), num_routes, down_partials.data_ptr<float>());','topk_weights.data_ptr<float>(), num_routes, pairs.data_ptr<int>(), pair_count, down_partials.data_ptr<float>());')
(root/'prototypes/sm70_nvfp4_moe_pairs.cu').write_text(src)
print('Pair-reuse upper-bound prototype generated')
