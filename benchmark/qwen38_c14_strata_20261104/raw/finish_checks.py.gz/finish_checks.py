import pathlib,subprocess,sys,time,os
p=pathlib.Path('/home/rah/qwen38-runs/20261104-c14-strata-round')
end=time.monotonic()+7200
while not (p/'post_control.done').exists():
 if time.monotonic()>end:raise TimeoutError('Post control not complete')
 time.sleep(3)
env=os.environ.copy();env['CUDA_VISIBLE_DEVICES']='1';env['PATH']='/usr/local/cuda-12.8/bin:'+env['PATH'];env['MAX_JOBS']='2'
with (p/'final_gpu_tests.log').open('x') as f:
 subprocess.run([sys.executable,'-m','pytest','test/manual/layers/test_sm70_hc_combine_norm.py','-q'],env=env,stdout=f,stderr=subprocess.STDOUT,check=True,timeout=600)
with (p/'live_check.log').open('x') as f:
 subprocess.run([sys.executable,str(p/'live_check.py')],stdout=f,stderr=subprocess.STDOUT,check=True,timeout=600)
(p/'final_checks.done').write_text('GPU tests and live service checks passed\n')
print('Final validation complete',flush=True)
