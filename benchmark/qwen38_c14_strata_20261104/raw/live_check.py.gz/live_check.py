import concurrent.futures,json,pathlib,requests,subprocess,sys,threading,time
p=pathlib.Path('/home/rah/qwen38-runs/20261104-c14-strata-round');url='http://127.0.0.1:8082'
end=time.monotonic()+1200
while time.monotonic()<end:
 try:
  if requests.get(url+'/health',timeout=2).status_code==200:break
 except requests.RequestException:pass
 time.sleep(3)
else:raise TimeoutError('8082 readiness')
info=requests.get(url+'/get_server_info',timeout=10).json()
assert info['max_req_input_len']==262138 and info['context_length']==262144
assert info['mm_attention_backend']=='fa2_v100'
assert info['speculative_num_steps']==3 and info['speculative_num_draft_tokens']==4
assert info['internal_states'][0]['effective_max_running_requests_per_dp']==8
assert info['max_total_tokens']==277280
assert info['max_mamba_cache_size']==48
pid=int(subprocess.check_output(['systemctl','--user','show','sglang-qwen38-8082.service','--property=MainPID','--value'],text=True))
variables=dict(x.split(b'=',1) for x in pathlib.Path(f'/proc/{pid}/environ').read_bytes().split(b'\0') if b'=' in x)
for key in ['SGLANG_SM70_MTP_LOCAL_TOP1','SGLANG_SM70_HC_COMBINE_NORM','SGLANG_SM70_AR_PUSH16']:assert variables.get(key.encode(),b'0')!=b'1',key
for key in ['SGLANG_SM70_BATCHED_MOE','SGLANG_SM70_BATCHED_MOE32','SGLANG_SM70_BATCHED_FUSIONS','SGLANG_MM_PREPROCESS_ON_CPU']:assert variables[key.encode()]==b'1',key
print('8082 ready; eight-request configuration and optimization flags verified',flush=True)
def check(case):
 a,b=case;start=time.perf_counter()
 r=requests.post(url+'/v1/chat/completions',json={'model':'qwen','messages':[{'role':'user','content':f'Calculate {a} + {b}. Reply with only the integer.'}],'temperature':0,'max_tokens':32,'chat_template_kwargs':{'enable_thinking':False}},timeout=90);r.raise_for_status();d=r.json();text=d['choices'][0]['message']['content'].strip();assert text==str(a+b),(case,text);return {'inputs':[a,b],'answer':text,'seconds':time.perf_counter()-start,'passed':True}
with concurrent.futures.ThreadPoolExecutor(max_workers=8) as e:cases=list(e.map(check,[(247,392),(131,208),(417,308),(926,617),(103,508),(194,217),(731,166),(549,304)]))
stream=[]
with requests.post(url+'/v1/chat/completions',json={'model':'qwen','messages':[{'role':'user','content':'Write exactly: server ready'}],'temperature':0,'max_tokens':32,'chat_template_kwargs':{'enable_thinking':False},'stream':True},stream=True,timeout=90) as r:
 r.raise_for_status()
 for line in r.iter_lines():
  if line.startswith(b'data: ') and line[6:]!=b'[DONE]':
   d=json.loads(line[6:]);stream.extend(c['delta'].get('content') or '' for c in d.get('choices',[]))
assert ''.join(stream).strip()=='server ready',stream
samples=[];stop=threading.Event()
def monitor():
 while not stop.is_set():
  try:
   g=subprocess.check_output(['nvidia-smi','--query-gpu=index,memory.free','--format=csv,noheader,nounits'],text=True,timeout=3)
   processes=subprocess.check_output(['nvidia-smi','--query-compute-apps=pid,used_memory','--format=csv,noheader,nounits'],text=True,timeout=3)
   samples.append({'time':time.time(),'gpu_free_mib':[[int(v.strip()) for v in s.split(',')] for s in g.splitlines()],'process_memory':processes})
  except Exception as e:print('Monitor sample skipped',repr(e),flush=True)
  stop.wait(0.5)
t=threading.Thread(target=monitor);t.start()
try:
 subprocess.run([sys.executable,'benchmark/qwen38_vision_v100_20261104/image_bench.py','--url',url,'--output',str(p/'live_images'),'--repeats','1','--label','restored_v5.5_c14'],check=True)
finally:stop.set();t.join()
image=json.loads((p/'live_images/results.jsonl').read_text().splitlines()[0])
selected={k:info[k] for k in ['mm_attention_backend','speculative_num_steps','speculative_num_draft_tokens','max_running_requests','max_total_tokens','context_length','max_req_input_len','chunked_prefill_size','mem_fraction_static']}
minimum=[min(s['gpu_free_mib'][i][1] for s in samples) for i in range(4)]
r={'passed':True,'release':'v100-qwen38-flash-next-v5.5','commit':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'url':url,'configuration':selected,'concurrent_text':cases,'streamed_text':''.join(stream).strip(),'image_result':image,'min_free_mib':minimum,'health_after':requests.get(url+'/health',timeout=5).status_code}
(p/'live_validation.json').write_text(json.dumps(r,indent=2)+'\n');(p/'live_memory.json').write_text(json.dumps(samples,indent=2)+'\n')
print(json.dumps({'passed':r['passed'],'image_seconds':image['seconds'],'min_free_mib':minimum,'health_after':r['health_after']}),flush=True)
