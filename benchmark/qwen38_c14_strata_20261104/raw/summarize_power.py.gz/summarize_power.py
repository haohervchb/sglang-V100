import json,statistics,pathlib
p=pathlib.Path(__file__).resolve().parent
out={}
for label in ['baseline','wide8']:
 samples=[json.loads(x) for x in (p/(label+'_nvml.jsonl')).read_text().splitlines()]
 for kind in ['code','prose']:
  runs=[json.loads(x) for x in (p/(label+'_'+kind)/'results.jsonl').read_text().splitlines()]
  reqs=[r for b in runs if b['concurrency']==1 for r in b['requests']]
  windows=[(r['start_unix_s']+r['ttft_s']+0.6,r['start_unix_s']+r['e2e_s']-0.6) for r in reqs]
  selected=[s for s in samples if any(a<=s['unix_s']<=b for a,b in windows)]
  covered=sum(any(a<=s['unix_s']<=b for s in samples) for a,b in windows)
  d=[g for s in selected for g in s['devices']]
  out[label+'_'+kind+'_c1']={'covered_requests':covered,'total_requests':len(reqs),'nvml_samples':len(selected),'guard_seconds':0.6,'mean_gpu_power_w':statistics.mean(g['power_w'] for g in d) if d else None,'sampled_sm_mhz':sorted(set(g['sm_mhz'] for g in d)),'any_throttle':any(g['throttle_reasons'] for g in d),'output_tokens_per_verify':sum(r['output_tokens'] for r in reqs)/sum(r['meta_info']['spec_verify_ct'] for r in reqs)}
(p/'c1_power_summary.json').write_text(json.dumps(out,indent=2)+'\n')
