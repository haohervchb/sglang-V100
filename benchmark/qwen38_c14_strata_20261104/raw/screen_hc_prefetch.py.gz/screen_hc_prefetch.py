import pathlib,sys,json,os
import torch
from sglang.jit_kernel.utils import load_jit
from sglang.jit_kernel.sm70_hc_mix import hc_down,hc_up
sys.path.insert(0,'/home/rah/sglang-V100/benchmark/qwen38_spec');from hardware_calibration import timed_graph
p=pathlib.Path('/home/rah/qwen38-runs/20261104-c14-strata-round');source=pathlib.Path('/home/rah/sglang-V100/python/sglang/jit_kernel/csrc/elementwise/sm70_hc_batch.cuh').read_text()
old='''  float acc[M][8] = {};
#pragma unroll
  for (int j = 0; j < (10240 + NT * 8 - 1) / (NT * 8); ++j) {'''
new='''  int4 prefetched[(10240 + NT * 8 - 1) / (NT * 8)];
#pragma unroll
  for(int j=0;j<(10240+NT*8-1)/(NT*8);++j){int k=(threadIdx.x+j*NT)*8;if(k<10240)prefetched[j]=*reinterpret_cast<const int4*>(w+row*10240+k);}
  float acc[M][8] = {};
#pragma unroll
  for (int j = 0; j < (10240 + NT * 8 - 1) / (NT * 8); ++j) {'''
assert old in source;source=source.replace(old,new).replace('int4 wv = *reinterpret_cast<const int4*>(w + row * 10240 + k);','int4 wv = prefetched[j];')
old='''  float acc[M][8] = {};
#pragma unroll
  for (int j = 0; j < 5; ++j) {'''
new='''  int4 prefetched[5];
#pragma unroll
  for(int j=0;j<5;++j)prefetched[j]=*reinterpret_cast<const int4*>(w+row*320+(sub+j*8)*8);
  float acc[M][8] = {};
#pragma unroll
  for (int j = 0; j < 5; ++j) {'''
assert old in source;source=source.replace(old,new).replace('int4 wv = *reinterpret_cast<const int4*>(w + row * 320 + k);','int4 wv = prefetched[j];');(p/'prototypes/sm70_hc_prefetch.cuh').write_text(source)
torch.manual_seed(202);records=[]
for m in [2,4]:
 x=torch.randn(m,10240,device='cuda',dtype=torch.float16);w=torch.randn(320,10240,device='cuda',dtype=torch.float16)*.01;u=torch.randn(10240,320,device='cuda',dtype=torch.float16)*.01;a=torch.empty(m,320,device='cuda',dtype=torch.float16);o=torch.empty(m,2560,device='cuda',dtype=torch.float16)
 mod=load_jit('q38_c14_hc_prefetch',m,cuda_files=[str(p/'prototypes/sm70_hc_prefetch.cuh')],cuda_wrappers=[('down',f'sglang::sm70_hc_batch::down_run<{m}>'),('up',f'sglang::sm70_hc_batch::up_run<{m}>')],extra_cuda_cflags=['--fmad=false'])
 old_a=hc_down(x,w);mod.down(x,w,a);torch.testing.assert_close(a,old_a,rtol=0,atol=0);old_o=hc_up(a,x,u);mod.up(a,x,u,o);torch.testing.assert_close(o,old_o,rtol=0,atol=0)
 for kind in ['down','up','both']:
  def old(_=0):return hc_down(x,w) if kind=='down' else (hc_up(a,x,u) if kind=='up' else hc_up(hc_down(x,w),x,u))
  def new(_=0):
   if kind in ['down','both']:mod.down(x,w,a)
   if kind in ['up','both']:mod.up(a,x,u,o)
  b=timed_graph(old,operations=16,replays=16,samples=5);n=timed_graph(new,operations=16,replays=16,samples=5);r={'rows':m,'kind':kind,'baseline_ms':b,'candidate_ms':n,'speedup':b/n,'bitwise':True};records.append(r);print(json.dumps(r),flush=True);(p/'hc_prefetch_micro.json').write_text(json.dumps(records,indent=2)+'\n')
(p/'hc_prefetch_micro.done').write_text('HC weight-prefetch screen complete\n')
