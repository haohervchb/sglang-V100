import pathlib,time,subprocess,sys,json,concurrent.futures
import requests
root=pathlib.Path('/home/rah/qwen38-runs/20261104-c14-strata-round');end=time.monotonic()+5400
while not (root/'moe_pairs_micro.done').exists():
 if time.monotonic()>end:raise TimeoutError('Expert pair screen not complete')
 time.sleep(2)
sys.path.insert(0,'/home/rah/sglang-V100/benchmark/qwen38_spec');from throughput import generate
cases=[c for c in json.loads(pathlib.Path('/home/rah/qwen38-runs/20261104-throughput/corpus.json').read_text())['cases'] if c['source_id']=='prose_1000'][:4];url='http://127.0.0.1:8083'
subprocess.run(['dcgmi','profile','--pause'],check=True)
try:
 for count in [1,4]:
  selected=cases[:count];requests.post(url+'/flush_cache',params={'timeout':30},timeout=120).raise_for_status()
  with concurrent.futures.ThreadPoolExecutor(max_workers=count) as pool:list(pool.map(lambda c:generate(url,c,32),selected))
  directory=root/f'compact_trace_c{count}';directory.mkdir()
  requests.post(url+'/start_profile',json={'output_dir':str(directory),'activities':['CPU','GPU'],'record_shapes':False,'with_stack':False,'profile_prefix':f'compact_c{count}'},timeout=120).raise_for_status()
  try:
   with concurrent.futures.ThreadPoolExecutor(max_workers=count) as pool:rows=list(pool.map(lambda c:generate(url,c,64),selected))
   (directory/'requests.json').write_text(json.dumps(rows))
  finally:requests.post(url+'/stop_profile',timeout=600).raise_for_status()
  print('Captured compact profile',count,flush=True)
finally:subprocess.run(['dcgmi','profile','--resume'],check=True)
(root/'compact_profile.done').write_text('Candidate kernel dispatch profiles complete\n')
