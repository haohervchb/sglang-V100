import pathlib,time,sys,json,collections,gc
root=pathlib.Path('/home/rah/qwen38-runs/20261104-c14-strata-round');end=time.monotonic()+3600
while not (root/'compact.done').exists():
 if time.monotonic()>end:raise TimeoutError('Compact full-model screen unfinished')
 time.sleep(2)
import torch
from torch.utils.cpp_extension import load_inline
from sglang.jit_kernel.sm70_nvfp4_moe_decode import sm70_nvfp4_moe_decode
sys.path.insert(0,'/home/rah/sglang-V100/benchmark/qwen38_spec');from hardware_calibration import timed_graph
mod=load_inline('q38_c14_moe_pairs',cpp_sources='',cuda_sources=(root/'prototypes/sm70_nvfp4_moe_pairs.cu').read_text(),functions=None,is_python_module=True,extra_cuda_cflags=['-O3','--use_fast_math'],verbose=False)
records=[]
for layer in [0,3,31]:
 cpu=torch.load(pathlib.Path('/home/rah/qwen38-runs/20261103-core-optimization/captured_moe')/f'layer_{layer:02d}.pt',map_location='cpu',weights_only=True,mmap=True)
 data={k:(v.cuda() if isinstance(v,torch.Tensor) else v) for k,v in cpu.items()};del cpu
 for m in [4,8,16]:
  for pattern,step in [('adjacent',1),('spread',117)]:
   idx=torch.arange(m,device='cuda')*step;case={k:(v.index_select(0,idx).contiguous() if isinstance(v,torch.Tensor) and v.ndim and v.shape[0]==2048 else v) for k,v in data.items()};r=m*10
   grouped=collections.defaultdict(list)
   for route,expert in enumerate(case['topk_ids'].flatten().tolist()):grouped[expert].append(route)
   pairs=[]
   for routes in grouped.values():
    for i in range(0,len(routes),2):pairs.append([routes[i],routes[i+1] if i+1<len(routes) else -1])
   pairs=torch.tensor(pairs,device='cuda',dtype=torch.int32)
   gp=torch.empty(40,r,320,device='cuda',dtype=torch.float32);act=torch.empty(r,160,device='cuda',dtype=torch.float16);dp=torch.empty(r,5,2560,device='cuda',dtype=torch.float32);out=torch.empty_like(case['hidden_states'])
   args=[case[k] for k in ['hidden_states','w1','w2','w1_scale','w2_scale','w1_global_scale','w2_global_scale','topk_ids','topk_weights']]
   def old(_=0):return sm70_nvfp4_moe_decode(*args)
   def new(_=0):mod.decode(*args,gp,act,dp,out,pairs);return out
   reference=old();torch.testing.assert_close(new(),reference,rtol=0,atol=0)
   b=timed_graph(old,operations=4,replays=8,samples=5);n=timed_graph(new,operations=4,replays=8,samples=5);row={'layer':layer,'rows':m,'pattern':pattern,'routes':r,'pairs':pairs.shape[0],'baseline_ms':b,'candidate_ms':n,'speedup':b/n,'bitwise':True,'scope':'Optimistic compute-only screen, prebuilt pairs; excludes runtime route planning'};records.append(row);(root/'moe_pairs_micro.json').write_text(json.dumps(records,indent=2)+'\n');print(json.dumps(row),flush=True)
   del args,case,idx,pairs,gp,act,dp,out,reference;gc.collect();torch.cuda.empty_cache()
 del data;gc.collect();torch.cuda.empty_cache()
(root/'moe_pairs_micro.done').write_text('Pair-reuse upper-bound screen complete\n')
