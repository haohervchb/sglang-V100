import gc,json,os,pathlib,sys,time
root=pathlib.Path('/home/rah/qwen38-runs/20261104-c14-strata-round');end=time.monotonic()+2400
while not (root/'baseline.done').exists():
 if time.monotonic()>end:raise TimeoutError('Baseline unfinished')
 time.sleep(2)
import torch
from sglang.jit_kernel.utils import load_jit
from sglang.jit_kernel.sm70_dense_gemv import linear,supported
sys.path.insert(0,'/home/rah/sglang-V100/benchmark/qwen38_spec')
from hardware_calibration import timed_graph
os.environ['SGLANG_SM70_DENSE_GEMV']='1';torch.manual_seed(312);torch.cuda.set_device(0)
rows=[]
def record(d):
 rows.append(d);(root/'wmma_micro.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(d),flush=True)
for m in [4,8,12,16,1,2]:
 for nt,kt,split in [(64,64,1),(64,64,4),(64,128,4),(128,64,4),(64,64,8),(128,128,1)]:
  mod=load_jit('q38_c14_wmma',m,nt,kt,split,cuda_files=[str(root/'prototypes/sm70_wmma.cuh')],cuda_wrappers=[('run',f'sglang::sm70_wmma_probe::run<{m},{nt},{kt},{split}>')])
  for n,k in [(4096,2560),(3584,2560),(2560,1536),(640,2560),(512,2560),(2560,2560),(320,10240),(10240,320),(62080,2560)]:
   if n%nt:continue
   x=torch.randn(m,k,device='cuda',dtype=torch.float16);w=torch.randn(n,k,device='cuda',dtype=torch.float16)*.01;p=torch.empty(split,m,n,device='cuda',dtype=torch.float32);out=torch.empty(m,n,device='cuda',dtype=torch.float16)
   def base(_=0):return linear(x,w) if supported(x,w) else torch.nn.functional.linear(x,w)
   def candidate(_=0):mod.run(x,w,p,out);return out
   ref=(x.float()@w.float().T).half();torch.testing.assert_close(candidate(),ref,rtol=.002,atol=.001)
   b=timed_graph(base,operations=8,replays=8,samples=3);c=timed_graph(candidate,operations=8,replays=8,samples=3)
   record({'m':m,'n':n,'k':k,'n_tile':nt,'k_tile':kt,'splits':split,'baseline_ms':b,'candidate_ms':c,'speedup':b/c,'rel_l2':((out.float()-ref.float()).norm()/ref.float().norm()).item()})
   del x,w,p,out,ref;gc.collect();torch.cuda.empty_cache()
(root/'wmma_micro.done').write_text('WMMA screen complete\n')
