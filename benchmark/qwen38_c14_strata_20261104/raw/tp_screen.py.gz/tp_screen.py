import json,pathlib,statistics,sys
from types import SimpleNamespace
import torch
import torch.distributed as dist
from sglang.jit_kernel.tests.test_custom_all_reduce import init_distributed
from sglang.jit_kernel.all_reduce import AllReduceAlgo
from sglang.srt.distributed.device_communicators.custom_all_reduce_v2 import CustomAllReduceV2
from sglang.srt.speculative.sm70_draft_top1 import exchange_top1
root=pathlib.Path('/home/rah/qwen38-runs/20261104-c14-strata-round')
rank,device,cpu,nccl,comm=init_distributed();comm.close();comm.disabled=True

def gather(x,dim=-1):
 out=[torch.empty_like(x) for _ in range(4)];dist.all_gather(out,x,group=nccl);return torch.cat(out,dim=dim)
group=SimpleNamespace(world_size=4,all_gather=gather)
def time_graph(fn,capture=None,ops=16):
 for _ in range(3):fn()
 torch.cuda.synchronize();dist.barrier(group=cpu);g=torch.cuda.CUDAGraph();stream=torch.cuda.Stream(device=device)
 import contextlib
 with capture() if capture else contextlib.nullcontext():
  with torch.cuda.graph(g,stream=stream):
   for _ in range(ops):out=fn()
 g.replay();torch.cuda.synchronize();times=[]
 for _ in range(5):
  dist.barrier(group=cpu);a=torch.cuda.Event(enable_timing=True);b=torch.cuda.Event(enable_timing=True);a.record()
  for _ in range(20):g.replay()
  b.record();b.synchronize();times.append(a.elapsed_time(b)/20/ops)
 return statistics.median(times),out
rows=[]
for m in [1,2,4,8,16,32]:
 torch.manual_seed(819+rank);valid=62080;local=torch.randn(m,valid+16,device=device,dtype=torch.float16);local[:,valid:]=float('inf');local32=local.float()
 def base():return gather(local[:,:valid].contiguous()).float().argmax(-1,keepdim=True)
 def new():return exchange_top1(local32,rank*valid,valid,group)
 for scenario in ['random','ties','nonfinite']:
  if scenario=='ties':local[:,:valid].zero_();local[:,5]=10.;local[:,-17]=10.
  if scenario=='nonfinite':local[:,7]=float('-inf');local[:,9]=float('inf');local[0,11]=float('nan')
  local32.copy_(local);expected=base();actual=new();torch.testing.assert_close(actual,expected,rtol=0,atol=0)
 local.normal_();local[:,valid:]=float('inf');local32.copy_(local)
 bm,_=time_graph(base);nm,out=time_graph(new);torch.testing.assert_close(out,base(),rtol=0,atol=0)
 record={'kind':'draft_top1','rows':m,'rank':rank,'full_gather_ms':bm,'top1_exchange_ms':nm,'speedup':bm/nm,'parity':True};rows.append(record)
 if rank==0:print(json.dumps(record),flush=True)
(root/f'tp_top1_rank{rank}.json').write_text(json.dumps(rows,indent=2)+'\n')
records=[]
for blocks in [None,1,2,4,8,16]:
 comm=CustomAllReduceV2(cpu,device,max_pull_size=1024*1024,max_push_size=1024*1024,max_push_blocks=blocks)
 for m in [1,2,4,8,12,16,32]:
  x=((torch.arange(m*2560,device=device)+rank)%7-3).half();expected=x.clone();dist.all_reduce(expected,group=nccl)
  algorithms=[AllReduceAlgo.ONE_SHOT_PUSH] if blocks is not None else list(AllReduceAlgo)
  for algo in algorithms:
   comm.override_algo=algo
   def run():return comm.custom_all_reduce(x)
   actual=run();torch.testing.assert_close(actual,expected,rtol=0,atol=0)
   ms,out=time_graph(run,comm.capture);torch.testing.assert_close(out,expected,rtol=0,atol=0)
   r={'kind':'all_reduce','rows':m,'bytes':x.numel()*2,'push_blocks':blocks,'algorithm':algo.name,'rank':rank,'ms':ms,'parity':True};records.append(r)
   if rank==0:print(json.dumps(r),flush=True)
 comm.close();comm.disabled=True
(root/f'allreduce_rank{rank}.json').write_text(json.dumps(records,indent=2)+'\n');dist.barrier(group=cpu);dist.destroy_process_group()
if rank==0:(root/'tp_screen.done').write_text('TP4 selection and collectives passed\n')
