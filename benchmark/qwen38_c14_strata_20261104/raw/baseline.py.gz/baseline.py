import json,pathlib,subprocess,sys,requests
root=pathlib.Path('/home/rah/qwen38-runs/20261104-c14-strata-round');repo=pathlib.Path('/home/rah/sglang-V100');sys.path.insert(0,str(repo/'benchmark/qwen38_spec'))
from core_audit import Monitor
(root/'original_server.json').write_text(json.dumps(requests.get('http://127.0.0.1:8082/get_server_info',timeout=15).json(),indent=2)+'\n')
(root/'original_service.txt').write_text(subprocess.check_output(['systemctl','--user','cat','sglang-qwen38-8082.service'],text=True))
(root/'baseline_commit.txt').write_text(subprocess.check_output(['git','rev-parse','HEAD'],text=True))
with Monitor(root/'baseline_nvml.jsonl'):
 for label,case,tokens,cs in [('baseline_prose','prose_1000',1024,[1,2,3,4]),('baseline_code','code_edit_8192',512,[1,2,4])]:
  argv=[sys.executable,'benchmark/qwen38_spec/throughput.py','run','--url','http://127.0.0.1:8082','--corpus','/home/rah/qwen38-runs/20261104-throughput/corpus.json','--case',case,'--requests','8','--output-tokens',str(tokens),'--concurrency',*map(str,cs),'--repeats','2','--label',label,'--output',str(root/label)]
  print('Run',label,flush=True)
  with (root/(label+'.log')).open('x') as f:subprocess.run(argv,cwd=repo,stdout=f,stderr=subprocess.STDOUT,check=True)
(root/'baseline.done').write_text('C1-C4 baseline complete\n')
