from pathlib import Path
import sys,time
sys.path.insert(0,'/home/rah/sglang-V100/benchmark/qwen38_spec')
from core_audit import Monitor
p=Path('/home/rah/qwen38-runs/20261104-c14-strata-round');end=time.monotonic()+3600
with Monitor(p/'wide8_nvml.jsonl'):
 while not (p/'wide8.done').exists() and time.monotonic()<end:time.sleep(2)
