import pathlib,time,sys,os,json
root=pathlib.Path('/home/rah/qwen38-runs/20261104-c14-strata-round');end=time.monotonic()+2400
while not (root/'cublas_micro.done').exists():
 if time.monotonic()>end:raise TimeoutError('cuBLAS screen unfinished')
 time.sleep(2)
import torch
from sglang.jit_kernel.utils import load_jit
from sglang.srt.layers.elementwise.hc_combine import hc_combine_split
from sglang.srt.layers.grouped_gemma_rmsnorm import grouped_gemma_rmsnorm
from sglang.jit_kernel.sm70_hc_mix import hc_apply_gate
sys.path.insert(0,'/home/rah/sglang-V100/benchmark/qwen38_spec');from hardware_calibration import timed_graph
mod=load_jit('q38_c14_hc_combine_norm',cuda_files=[str(root/'prototypes/hc_combine_norm.cuh')],cuda_wrappers=[('run','sglang::sm70_hc_combine_norm::run')],extra_include_paths=['/home/rah/sglang-V100/python/sglang/jit_kernel/csrc/elementwise'])
torch.manual_seed(789);records=[]
for m in [1,2,4,8,12,16,32]:
 y=torch.randn(m,2560,device='cuda',dtype=torch.float16);r=torch.randn(m,10240,device='cuda',dtype=torch.float16);n=torch.randn_like(r);w=torch.randn(4,10240,device='cuda',dtype=torch.float16)*.01;gamma=torch.randn(10240,device='cuda',dtype=torch.float16)*.01;p=torch.randn(m,8,4,device='cuda',dtype=torch.float32);o=torch.empty_like(r);norm=torch.empty_like(r)
 for pre in [False,True] if m in [2,4] else [False]:
  def base(_=0):
   out=hc_apply_gate(y,r,p) if pre else hc_combine_split(y,r,n,w,4,2560)
   return out,grouped_gemma_rmsnorm(out,gamma,2560,1e-6)
  def candidate(_=0):mod.run(y,r,n,w,gamma,p,o,norm,1e-6,pre);return o,norm
  for scale in [1.,-.5,0.]:
   y.mul_(scale);expected=base();actual=candidate();torch.testing.assert_close(actual[0],expected[0],rtol=0,atol=0);torch.testing.assert_close(actual[1],expected[1],rtol=0,atol=0)
  y.normal_();candidate();graph=torch.cuda.CUDAGraph()
  with torch.cuda.graph(graph):candidate()
  y.neg_();graph.replay();expected=base();torch.testing.assert_close(o,expected[0],rtol=0,atol=0);torch.testing.assert_close(norm,expected[1],rtol=0,atol=0)
  b=timed_graph(base,operations=32,replays=16,samples=5);c=timed_graph(candidate,operations=32,replays=16,samples=5);row={'rows':m,'precomputed_gate':pre,'baseline_ms':b,'candidate_ms':c,'speedup':b/c,'bitwise':True};records.append(row);(root/'hc_norm_micro.json').write_text(json.dumps(records,indent=2)+'\n');print(json.dumps(row),flush=True)
(root/'hc_norm_micro.done').write_text('HC combine/norm screen complete\n')
