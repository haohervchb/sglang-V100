"""Describe a reviewed, staged tree for upload through the connected GitHub API."""
import json,pathlib,subprocess
repo=pathlib.Path('/home/rah/sglang-V100');root=pathlib.Path('/home/rah/qwen38-runs/20261104-c14-strata-round/publication');root.mkdir(exist_ok=True)
def git(*args):return subprocess.check_output(['git',*args],cwd=repo)
base=git('rev-parse','HEAD').decode().strip();tree=git('write-tree').decode().strip();changes=git('diff','--cached','--name-status','-z').split(b'\0');entries=[]
for i in range(0,len(changes)-1,2):
 status,path=changes[i].decode(),changes[i+1].decode()
 assert status in ['A','M'],(status,path)
 raw=git('ls-files','--stage','--',path).decode().split();mode,sha=raw[:2]
 assert mode in ['100644','100755'],(mode,path)
 data=git('show',':'+path);snap=root/'upload_blobs'/sha;snap.parent.mkdir(exist_ok=True);snap.write_bytes(data)
 entries.append({'path':path,'mode':mode,'type':'blob','sha':sha,'bytes':len(data),'snapshot':str(snap)})
(root/'upload_manifest.json').write_text(json.dumps({'base_commit':base,'base_tree':git('rev-parse','HEAD^{tree}').decode().strip(),'target_tree':tree,'branch':git('branch','--show-current').decode().strip(),'entries':entries},indent=2)+'\n')
print(json.dumps({'files':len(entries),'bytes':sum(x['bytes'] for x in entries),'tree':tree}))
