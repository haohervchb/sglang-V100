// Independent SM70 FP16 projection experiment. FP32 accumulation; no model approximation.
#include <cuda_fp16.h>
#include <mma.h>
#include <sgl_kernel/tensor.h>
#include <sgl_kernel/utils.cuh>
#include <tvm/ffi/container/tensor.h>
namespace sglang::sm70_wmma_probe {
using namespace nvcuda;
template<int M,int NTILE,int KTILE,int SPLITS>
__global__ void project(const half* __restrict__ x,const half* __restrict__ w,float* __restrict__ partial,int N,int K){
 constexpr int WARPS=4, THREADS=128, FRAGS=NTILE/16/WARPS;
 __shared__ __align__(32) half sx[16*KTILE];
 __shared__ __align__(32) half sw[NTILE*KTILE];
 __shared__ __align__(32) float result[16*NTILE];
 const int warp=threadIdx.x/32;
 const int nbase=blockIdx.x*NTILE;
 const int tiles=(K+15)/16, per=(tiles+SPLITS-1)/SPLITS;
 const int begin=blockIdx.y*per*16, end=min(K,begin+per*16);
 wmma::fragment<wmma::accumulator,16,16,16,float> acc[FRAGS];
 #pragma unroll
 for(int f=0;f<FRAGS;f++)wmma::fill_fragment(acc[f],0.f);
 for(int kb=begin;kb<end;kb+=KTILE){
  for(int i=threadIdx.x*8;i<16*KTILE;i+=THREADS*8){int m=i/KTILE,k=kb+i%KTILE;*reinterpret_cast<int4*>(sx+i)=(m<M&&k<end)?*reinterpret_cast<const int4*>(x+m*K+k):make_int4(0,0,0,0);}
  for(int i=threadIdx.x*8;i<NTILE*KTILE;i+=THREADS*8){int n=nbase+i/KTILE,k=kb+i%KTILE;*reinterpret_cast<int4*>(sw+i)=(k<end)?*reinterpret_cast<const int4*>(w+n*K+k):make_int4(0,0,0,0);}
  __syncthreads();
  #pragma unroll
  for(int kk=0;kk<KTILE;kk+=16){
   if(kb+kk<end){
    wmma::fragment<wmma::matrix_a,16,16,16,half,wmma::row_major> a;
    wmma::load_matrix_sync(a,sx+kk,KTILE);
    #pragma unroll
    for(int f=0;f<FRAGS;f++){
     wmma::fragment<wmma::matrix_b,16,16,16,half,wmma::col_major> b;
     wmma::load_matrix_sync(b,sw+(warp+f*WARPS)*16*KTILE+kk,KTILE);
     wmma::mma_sync(acc[f],a,b,acc[f]);
    }
   }
  }
  __syncthreads();
 }
 #pragma unroll
 for(int f=0;f<FRAGS;f++)wmma::store_matrix_sync(result+(warp+f*WARPS)*16,acc[f],NTILE,wmma::mem_row_major);
 __syncthreads();
 for(int i=threadIdx.x;i<M*NTILE;i+=THREADS){int m=i/NTILE,n=nbase+i%NTILE;partial[(blockIdx.y*M+m)*N+n]=result[i];}
}
template<int M,int SPLITS>
__global__ void finish(const float* __restrict__ partial,half* __restrict__ output,int N){
 int i=blockIdx.x*blockDim.x+threadIdx.x;if(i>=M*N)return;float sum=0.f;
 #pragma unroll
 for(int s=0;s<SPLITS;s++)sum+=partial[s*M*N+i];output[i]=__float2half_rn(sum);
}
template<int M,int NTILE,int KTILE,int SPLITS>
void run(tvm::ffi::TensorView x,tvm::ffi::TensorView w,tvm::ffi::TensorView partial,tvm::ffi::TensorView output){
 static_assert(M>=1&&M<=16);static_assert(NTILE==64||NTILE==128);static_assert(KTILE%16==0);
 using namespace host;auto dev=SymbolicDevice{};dev.set_options<kDLCUDA>();auto N=SymbolicSize{},K=SymbolicSize{};
 TensorMatcher({M,K}).with_dtype<half>().with_device(dev).verify(x);
 TensorMatcher({N,K}).with_dtype<half>().with_device(dev).verify(w);
 TensorMatcher({SPLITS,M,N}).with_dtype<float>().with_device(dev).verify(partial);
 TensorMatcher({M,N}).with_dtype<half>().with_device(dev).verify(output);
 RuntimeCheck(N.unwrap()%NTILE==0&&K.unwrap()%16==0,"Aligned projection geometry required");
 RuntimeCheck(reinterpret_cast<uintptr_t>(x.data_ptr())%32==0&&reinterpret_cast<uintptr_t>(w.data_ptr())%32==0,"32-byte operand alignment required");
 LaunchKernel(dim3(N.unwrap()/NTILE,SPLITS),128,dev.unwrap())(project<M,NTILE,KTILE,SPLITS>,static_cast<const half*>(x.data_ptr()),static_cast<const half*>(w.data_ptr()),static_cast<float*>(partial.data_ptr()),int(N.unwrap()),int(K.unwrap()));
 LaunchKernel((M*N.unwrap()+255)/256,256,dev.unwrap())(finish<M,SPLITS>,static_cast<const float*>(partial.data_ptr()),static_cast<half*>(output.data_ptr()),int(N.unwrap()));
}
}
