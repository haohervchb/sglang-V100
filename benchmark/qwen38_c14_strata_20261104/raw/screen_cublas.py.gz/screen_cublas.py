import pathlib,time,sys,os,json,gc
root=pathlib.Path('/home/rah/qwen38-runs/20261104-c14-strata-round');end=time.monotonic()+1800
while not (root/'wmma_v3_final.done').exists():
 if time.monotonic()>end:raise TimeoutError('WMMA screen unfinished')
 time.sleep(2)
import torch
from torch.utils.cpp_extension import load_inline
from sglang.jit_kernel.sm70_dense_gemv import linear,supported
sys.path.insert(0,'/home/rah/sglang-V100/benchmark/qwen38_spec');from hardware_calibration import timed_graph
os.environ['SGLANG_SM70_DENSE_GEMV']='1';torch.cuda.set_device(0);torch.manual_seed(970)
mod=load_inline('q38_c14_cublas_probe',cpp_sources='int run(torch::Tensor, torch::Tensor, torch::Tensor, int);',cuda_sources=(root/'prototypes/cublas_probe.cu').read_text(),functions=['run'],extra_cuda_cflags=['-O3'],extra_ldflags=['-lcublas'],verbose=False)
records=[]
for m in [4,8,16,12,1,2]:
 for n,k in [(4096,2560),(3584,2560),(2560,1536),(2560,2560),(320,10240),(10240,320)]:
  x=torch.randn(m,k,device='cuda',dtype=torch.float16);w=torch.randn(n,k,device='cuda',dtype=torch.float16)*.01;o=torch.empty(m,n,device='cuda',dtype=torch.float16)
  ref=(x.float()@w.float().T).half()
  def base(_):return linear(x,w) if supported(x,w) else torch.nn.functional.linear(x,w)
  bm=timed_graph(base,operations=8,replays=8,samples=3);results=[]
  for algo in [-1,*range(24),*range(99,116)]:
   status=mod.run(x,w,o,algo)
   if status:continue
   try:torch.testing.assert_close(o,ref,rtol=.002,atol=.001)
   except AssertionError:
    results.append({'algo':algo,'numeric_rejected':True,'max_abs_error':float((o-ref).abs().max())});continue
   cm=timed_graph(lambda _,a=algo:mod.run(x,w,o,a),operations=8,replays=8,samples=3)
   results.append({'algo':algo,'ms':cm,'speedup':bm/cm})
  row={'m':m,'n':n,'k':k,'baseline_ms':bm,'algorithms':results};records.append(row);(root/'cublas_micro.json').write_text(json.dumps(records,indent=2)+'\n')
  print(json.dumps({'m':m,'n':n,'k':k,'best':sorted([x for x in results if 'ms' in x],key=lambda x:x['ms'])[:3],'baseline_ms':bm}),flush=True)
  del x,w,o,ref;gc.collect();torch.cuda.empty_cache()
(root/'cublas_micro.done').write_text('cuBLAS screen complete\n')
