import json,os,pathlib,signal,subprocess,sys,time
import requests
root=pathlib.Path('/home/rah/qwen38-runs/20261104-c14-strata-round');repo=pathlib.Path('/home/rah/sglang-V100');corpora=pathlib.Path('/home/rah/qwen38-runs/20261104-throughput');service='sglang-qwen38-8082.service';url='http://127.0.0.1:8083'
state={'controller_pid':os.getpid(),'stage':'starting','restore_required':False};process=None

def save(**kw):state.update(kw);(root/'STATE.json').write_text(json.dumps(state,indent=2)+'\n')
def ready(endpoint,proc=None):
 end=time.monotonic()+1500
 while time.monotonic()<end:
  if proc and proc.poll() is not None:raise RuntimeError('Server exited during startup')
  try:
   if requests.get(endpoint+'/health',timeout=2).ok:return
  except requests.RequestException:pass
  time.sleep(3)
 raise TimeoutError('Readiness timeout')
def run(label,argv):
 save(current_job=label);print('Run',label,flush=True)
 with (root/(label+'.log')).open('x') as f:r=subprocess.run([sys.executable,*argv],cwd=repo,stdout=f,stderr=subprocess.STDOUT)
 if r.returncode:raise RuntimeError(label+' failed')
def bench(label,case='prose_1000',tokens=1024,concurrencies=(1,2,3,4),repeats=2,speed=False):
 run(label,['benchmark/qwen38_spec/throughput.py','run','--url',url,'--corpus',str(corpora/('speed_agents.json' if speed else 'corpus.json')),'--case',case,'--requests','20' if speed else '8','--output-tokens',str(tokens),'--concurrency',*map(str,concurrencies),'--repeats',str(repeats),'--label',label,'--output',str(root/label),*(['--natural-eos'] if speed else [])])
deadline=time.monotonic()+7200
while not (root/'wide8.done').exists():
 if time.monotonic()>deadline:raise TimeoutError('Wide profile unfinished')
 time.sleep(3)
base=json.loads((root/'baseline_code/summary.json').read_text());wide=json.loads((root/'wide8_code/summary.json').read_text())
import statistics
base_rate=statistics.mean(r['median_decode_tok_s'] for r in base if r['concurrency']==1)
wide_rate=statistics.mean(r['median_decode_tok_s'] for r in wide if r['concurrency']==1)
if wide_rate<base_rate*1.05:
 (root/'adaptive.skipped').write_text('Eight-token code gain below5%; noadaptiveexperiment warranted\n');sys.exit(0)
old=json.loads((root/'STATE.json').read_text());assert old['stage']=='awaiting_selection' and old['variant']=='wide8'
state['restore_required']=True;save(stage='taking_over_for_adaptive')
old_pid=old['controller_pid'];cmd=pathlib.Path(f'/proc/{old_pid}/cmdline').read_bytes().split(b'\0');assert str(root/'run_candidates.py').encode() in cmd
os.kill(old_pid,signal.SIGTERM)
old_server=old['server_pid']
try:os.killpg(old_server,signal.SIGTERM)
except ProcessLookupError:pass
for _ in range(40):
 try:
  status=pathlib.Path(f'/proc/{old_server}/stat').read_text().split()[2]
  if status=='Z':break
 except FileNotFoundError:break
 time.sleep(1)
else:
 try:os.killpg(old_server,signal.SIGKILL)
 except ProcessLookupError:pass

try:
 save(stage='stopping_production',restore_required=True);subprocess.run(['systemctl','--user','stop',service],check=True)
 for label,steps,drafts,cap in [('adaptive',3,4,4)]:
  env=os.environ.copy();env.update(SGLANG_PYTHON=sys.executable,CUDA_VISIBLE_DEVICES='0,1,2,3',PORT='8083',PYTHONUNBUFFERED='1',SGLANG_SM70_MTP_LOCAL_TOP1='1',SGLANG_SM70_HC_COMBINE_NORM='1',SGLANG_SM70_AR_PUSH16='1');env['PATH']=str(pathlib.Path(sys.executable).parent)+':/usr/local/cuda-12.8/bin:'+env['PATH']
  argv=['bash','scripts/serve_qwen38_flash_next_nvfp4_v100_throughput.sh','RadixArk/Qwen3.8-Flash-Next-NVFP4','--speculative-num-steps',str(steps),'--speculative-num-draft-tokens',str(drafts),'--max-running-requests',str(cap),'--cuda-graph-bs',*map(str,range(1,cap+1)),'--speculative-adaptive','--speculative-adaptive-config',str(root/'adaptive.json')]
  (root/(label+'_launch.json')).write_text(json.dumps({'argv':argv,'env':{k:env[k] for k in ['SGLANG_SM70_MTP_LOCAL_TOP1','SGLANG_SM70_HC_COMBINE_NORM','SGLANG_SM70_AR_PUSH16']},'base_commit':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()},indent=2))
  with (root/(label+'_server.log')).open('x') as f:
   process=subprocess.Popen(argv,cwd=repo,env=env,stdout=f,stderr=subprocess.STDOUT,start_new_session=True);save(stage='loading',variant=label,server_pid=process.pid);print('Loading',label,flush=True)
   try:
    ready(url,process);info=requests.get(url+'/get_server_info',timeout=20).json();assert info['context_length']==262144 and info['max_req_input_len']>=262000;assert info['internal_states'][0]['effective_max_running_requests_per_dp']==cap;(root/(label+'_server.json')).write_text(json.dumps(info,indent=2))
    save(stage='validating');run(label+'_checks',['benchmark/qwen38_spec/check.py','--url',url,'--full-context','--output',str(root/(label+'_checks.json'))]);run(label+'_tools',['benchmark/qwen38_spec/check_tools.py','--url',url,'--output',str(root/(label+'_tools.json'))]);run(label+'_shared',['benchmark/qwen38_spec/check_shared_document.py','--concurrency',str(cap),'--output',str(root/(label+'_shared.json'))])
    with (root/(label+'_mm.log')).open('x') as mf:subprocess.run([sys.executable,'benchmark/qwen38_nvfp4_v100_multimodal_20260909/validate.py','--base-url',url,'--tag',label+'_mm','--output-dir',str(root)],cwd=repo,stdout=mf,stderr=subprocess.STDOUT)
    mm=json.loads((root/(label+'_mm_results.json')).read_text());failed=[c for c in mm['cases'] if not c['passed']];assert len(mm['cases'])==12 and mm.get('health_status')==200;assert not failed or len(failed)==1 and failed[0]['name']=='ocr' and failed[0]['text'].strip()=='V10 CHECK 4827',failed
    save(stage='benchmarking');bench(label+'_prose');bench(label+'_code','code_edit_8192',512,(1,2,4));bench(label+'_speed','speed',512,(1,4),1,True)
    if cap==8:bench(label+'_c8','prose_1000',1024,(8,),2)
    (root/(label+'.done')).write_text('Validated and benchmarked\n');save(stage='awaiting_selection');print('Awaiting selection',label,flush=True);deadline=time.monotonic()+2400;action=root/(label+'.action')
    while not action.exists():
     if time.monotonic()>deadline:raise TimeoutError('Selection timed out')
     time.sleep(1)
    choice=action.read_text().strip();assert choice in ['next','deploy','restore'],choice
   finally:
    if process.poll() is None:
     os.killpg(process.pid,signal.SIGTERM)
     try:process.wait(timeout=40)
     except subprocess.TimeoutExpired:os.killpg(process.pid,signal.SIGKILL);process.wait()
    process=None;time.sleep(3)
   if choice!='next':break
except BaseException as e:save(error=repr(e));raise
finally:
 save(stage='restoring');subprocess.run(['systemctl','--user','start',service],check=True);ready('http://127.0.0.1:8082');save(stage='restored',restore_required=False);print('8082 restored',flush=True)
