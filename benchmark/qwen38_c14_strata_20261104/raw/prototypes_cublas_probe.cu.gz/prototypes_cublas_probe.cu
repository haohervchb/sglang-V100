#include <torch/extension.h>
#include <ATen/cuda/CUDAContext.h>
#include <c10/cuda/CUDAGuard.h>
#include <cublas_v2.h>
int run(torch::Tensor x,torch::Tensor w,torch::Tensor out,int algo){
 const c10::cuda::CUDAGuard guard(x.device());auto h=at::cuda::getCurrentCUDABlasHandle();
 cublasMath_t old_math;cublasGetMathMode(h,&old_math);
 cublasSetMathMode(h,static_cast<cublasMath_t>(CUBLAS_TENSOR_OP_MATH|CUBLAS_MATH_DISALLOW_REDUCED_PRECISION_REDUCTION));
 float alpha=1.f,beta=0.f;int m=x.size(0),k=x.size(1),n=w.size(0);
 auto status=cublasGemmEx(h,CUBLAS_OP_T,CUBLAS_OP_N,n,m,k,&alpha,w.data_ptr(),CUDA_R_16F,k,x.data_ptr(),CUDA_R_16F,k,&beta,out.data_ptr(),CUDA_R_16F,n,CUBLAS_COMPUTE_32F,static_cast<cublasGemmAlgo_t>(algo));
 cublasSetMathMode(h,old_math);return static_cast<int>(status);
}
