import pathlib,time,requests,json,subprocess,sys
root=pathlib.Path('/home/rah/qwen38-runs/20261104-c14-strata-round');end=time.monotonic()+7200
while time.monotonic()<end:
 try:
  state=json.loads((root/'STATE.json').read_text())
  if state.get('stage')=='restored' and not state.get('restore_required'):break
 except (FileNotFoundError,json.JSONDecodeError):pass
 time.sleep(3)
else:raise TimeoutError('Production restoration pending')
url='http://127.0.0.1:8082';info=requests.get(url+'/get_server_info',timeout=15).json();assert info['speculative_num_steps']==3 and info['speculative_num_draft_tokens']==4 and info['max_running_requests']==8
pid=int(subprocess.check_output(['systemctl','--user','show','sglang-qwen38-8082.service','--property=MainPID','--value'],text=True));env=dict(v.split(b'=',1) for v in pathlib.Path(f'/proc/{pid}/environ').read_bytes().split(b'\0') if b'=' in v)
for name in ['SGLANG_SM70_MTP_LOCAL_TOP1','SGLANG_SM70_HC_COMBINE_NORM','SGLANG_SM70_AR_PUSH16']:assert env.get(name.encode(),b'0')!=b'1',name
for label,case,tokens,cs,speed in [('post_prose','prose_1000',1024,[4,3,2,1],False),('post_code','code_edit_8192',512,[4,2,1],False),('post_speed','speed',512,[4,1],True),('post_c8','prose_1000',1024,[8],False)]:
 argv=[sys.executable,'benchmark/qwen38_spec/throughput.py','run','--url',url,'--corpus','/home/rah/qwen38-runs/20261104-throughput/'+('speed_agents.json' if speed else 'corpus.json'),'--case',case,'--requests','20' if speed else '8','--output-tokens',str(tokens),'--concurrency',*map(str,cs),'--repeats','1','--label',label,'--output',str(root/label),*(['--natural-eos'] if speed else [])]
 with (root/(label+'.log')).open('x') as f:subprocess.run(argv,cwd='/home/rah/sglang-V100',stdout=f,stderr=subprocess.STDOUT,check=True)
 print('Completed',label,flush=True)
(root/'post_control.done').write_text('Restored-profile control complete\n')
