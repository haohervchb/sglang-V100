import pathlib,subprocess,sys,time,os
p=pathlib.Path('/home/rah/qwen38-runs/20261104-c14-strata-round');end=time.monotonic()+1800
while not (p/'hc_prefetch_micro.done').exists():
 if time.monotonic()>end:raise TimeoutError('HC prefetch test unfinished')
 time.sleep(2)
env=os.environ.copy();env['PYTHONPATH']='/home/rah/sglang-V100/python';env['CUDA_VISIBLE_DEVICES']='0,1,2,3';env['MAX_JOBS']='2';env['NCCL_P2P_LEVEL']='NVL'
subprocess.run([sys.executable,'-m','torch.distributed.run','--standalone','--nproc-per-node','4',str(p/'tp_screen.py')],env=env,check=True,timeout=1200)
