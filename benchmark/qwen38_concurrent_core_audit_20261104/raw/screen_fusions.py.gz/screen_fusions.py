"""Isolated experimental extensions; production sources remain unchanged."""
import gc,json,os,pathlib,sys,time
root=pathlib.Path('/home/rah/qwen38-runs/20261104-concurrent-core-audit');repo=pathlib.Path('/home/rah/sglang-V100')
end=time.monotonic()+1800
while time.monotonic()<end:
 try:
  if json.loads((root/'STATE.json').read_text()).get('stage')=='captured':break
 except (FileNotFoundError,json.JSONDecodeError):pass
 time.sleep(2)
else:raise TimeoutError('Audit capture did not complete')
import torch
from sglang.jit_kernel.utils import load_jit
sys.path.insert(0,str(repo/'benchmark/qwen38_spec'))
from hardware_calibration import timed_graph
src=repo/'python/sglang/jit_kernel/csrc/elementwise';proto=root/'prototypes';proto.mkdir(exist_ok=True)
for name in ['sm70_small_gemm.cuh','sm70_hc_batch.cuh','sm70_qwen_gdn.cuh','sm70_qwen_fusions.cuh']:
 s=(src/name).read_text().replace('M == 2 || M == 4','M == 2 || M == 4 || M == 8 || M == 12 || M == 16')
 s=s.replace('rows.unwrap() == 1 || rows.unwrap() == 2 || rows.unwrap() == 4','rows.unwrap() >= 1 && rows.unwrap() <= 16')
 (proto/name).write_text(s)
def module(label,file,wrappers,flags=None):
 return load_jit('q38_concurrent_audit',label,cuda_files=[str(proto/file)],cuda_wrappers=wrappers,extra_cuda_cflags=flags or [])
def ms(fn):return timed_graph(lambda _:fn(),operations=8,replays=8,samples=3)
records=[]
def record(row):
 records.append(row);(root/'fusion_micro.json').write_text(json.dumps(records,indent=2)+'\n');print(json.dumps(row),flush=True)
torch.manual_seed(731);torch.cuda.set_device(0)
mod=module('gate','sm70_qwen_fusions.cuh',[('run','sglang::sm70_qwen_fusions::run<512>')],['--fmad=false'])
for m in [8,12,16]:
 x=torch.randn(m,2560,device='cuda',dtype=torch.float16);w=torch.randn(1,2560,device='cuda',dtype=torch.float16)*.01;v=torch.randn_like(x);o=torch.empty_like(x)
 def old():return torch.sigmoid(torch.nn.functional.linear(x,w))*v
 def new():mod.run(x,w,v,o);return o
 torch.testing.assert_close(new(),torch.sigmoid((x.float()@w.float().T).half())*v,rtol=.002,atol=.001)
 b=ms(old);n=ms(new);record({'kind':'gate','rows':m,'baseline_ms':b,'native_ms':n,'speedup':b/n})
del x,w,v,o;gc.collect();torch.cuda.empty_cache()
for m in [8,12,16]:
 x=torch.randn(m,10240,device='cuda',dtype=torch.float16);w=torch.randn(320,10240,device='cuda',dtype=torch.float16)*.01;u=torch.randn(10240,320,device='cuda',dtype=torch.float16)*.01;a=torch.empty(m,320,device='cuda',dtype=torch.float16);o=torch.empty(m,2560,device='cuda',dtype=torch.float16)
 mod=module('hc'+str(m),'sm70_hc_batch.cuh',[('down',f'sglang::sm70_hc_batch::down_run<{m}>'),('up',f'sglang::sm70_hc_batch::up_run<{m}>')],['--fmad=false'])
 @torch.compile
 def old(x,w,u):
  a=torch.nn.functional.silu(torch.nn.functional.linear(x,w)/4)
  p=torch.sigmoid(torch.nn.functional.linear(a,u)).unflatten(-1,(4,2560))
  return (p*x.unflatten(-1,(4,2560))).mean(-2)
 def new():mod.down(x,w,a);mod.up(a,x,u,o);return o
 refa=torch.nn.functional.silu((x.float()@w.float().T).half().float()/4).half();ref=((torch.sigmoid((refa.float()@u.float().T).half().float())*x.float()).view(m,4,2560).mean(1)).half()
 torch.testing.assert_close(new(),ref,rtol=.002,atol=.0004)
 b=ms(lambda:old(x,w,u));n=ms(new);record({'kind':'hc_mix','rows':m,'baseline_ms':b,'native_ms':n,'speedup':b/n,'rel_l2':((o.float()-ref.float()).norm()/ref.float().norm()).item()})
 del x,w,u,a,o,ref,refa;gc.collect();torch.cuda.empty_cache()
for m in [8,12,16]:
 for threads,lanes in [(64,32),(128,32),(128,16),(256,32)]:
  mod=module(f'dense{m}_{threads}_{lanes}','sm70_small_gemm.cuh',[('run',f'sglang::sm70_small_gemm::run<{m},{threads},{lanes}>')])
  for n,k in [(4096,2560),(3584,2560),(2560,1536),(320,2560),(2560,160),(512,2560),(640,2560),(2560,2560),(62080,2560)]:
   x=torch.randn(m,k,device='cuda',dtype=torch.float16);w=torch.randn(n,k,device='cuda',dtype=torch.float16)*.01;o=torch.empty(m,n,device='cuda',dtype=torch.float16)
   def old():return torch.nn.functional.linear(x,w)
   def new():mod.run(x,w,o);return o
   ref=(x.float()@w.float().T).half();torch.testing.assert_close(new(),ref,rtol=.002,atol=.001)
   b=ms(old);d=ms(new);record({'kind':'dense','rows':m,'n':n,'k':k,'threads':threads,'lanes':lanes,'baseline_ms':b,'native_ms':d,'speedup':b/d})
   del x,w,o,ref;gc.collect();torch.cuda.empty_cache()
for m in [8,12,16]:
 for threads in [64,128,256]:
  mod=module(f'gdn{m}_{threads}','sm70_qwen_gdn.cuh',[('run',f'sglang::sm70_qwen_gdn::run<{m},{threads}>')])
  x=torch.randn(m,2560,device='cuda',dtype=torch.float16);w=torch.randn(4096,2560,device='cuda',dtype=torch.float16)*.01;t=torch.randn(24,2560,device='cuda',dtype=torch.float16)*.01
  qkv=torch.empty(m,2560,device='cuda',dtype=torch.float16);z=torch.empty(m,1536,device='cuda',dtype=torch.float16);b=torch.empty(m,12,device='cuda',dtype=torch.float16);a=torch.empty_like(b)
  def old():
   main=torch.nn.functional.linear(x,w);tail=torch.nn.functional.linear(x,t)
   return main[:,:2560].contiguous(),main[:,2560:].contiguous(),tail[:,:12].contiguous(),tail[:,12:].contiguous()
  def new():mod.run(x,w,t,qkv,z,b,a);return qkv,z,b,a
  ref=(x.float()@w.float().T).half();tail=(x.float()@t.float().T).half()
  for actual,expected in zip(new(),[ref[:,:2560],ref[:,2560:],tail[:,:12],tail[:,12:]]):torch.testing.assert_close(actual,expected,rtol=.002,atol=.001)
  bm=ms(old);nm=ms(new);record({'kind':'gdn_qkvzba','rows':m,'threads':threads,'baseline_ms':bm,'native_ms':nm,'speedup':bm/nm})
  del x,w,t,qkv,z,b,a,ref,tail;gc.collect();torch.cuda.empty_cache()
(root/'fusion_micro.done').write_text('All checks and timings complete\n')
