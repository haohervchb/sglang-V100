import concurrent.futures,json,pathlib,subprocess,sys,time
import requests
p=pathlib.Path('/home/rah/qwen38-runs/20261104-concurrent-core-audit');repo=pathlib.Path('/home/rah/sglang-V100');sys.path.insert(0,str(repo/'benchmark/qwen38_spec'))
from core_audit import Monitor
from throughput import generate
end=time.monotonic()+1800
while not (p/'fusion_micro.done').exists():
 if time.monotonic()>end:raise TimeoutError('Fusion microbench did not finish')
 time.sleep(2)
url='http://127.0.0.1:8082';corpus=pathlib.Path('/home/rah/qwen38-runs/20261104-throughput/corpus.json');cases=[c for c in json.loads(corpus.read_text())['cases'] if c['source_id']=='prose_1000'][:4]
for label,fields in [('dcgm_sm_c4short',[1001,1002,1003,1005,1009,1010,1011,1012]),('dcgm_tensor_c4short',[1001,1004,1005,1009,1010,1011,1012])]:
 with Monitor(p/(label+'_nvml.jsonl')),Monitor(p/(label+'.jsonl'),fields):
  requests.post(url+'/flush_cache',params={'timeout':30},timeout=120).raise_for_status();time.sleep(3)
  stamp=time.time();start=time.perf_counter()
  with concurrent.futures.ThreadPoolExecutor(max_workers=4) as e:result=list(e.map(lambda c:generate(url,c,2048),cases))
  elapsed=time.perf_counter()-start;row={'label':label,'case':'prose_1000','concurrency':4,'cached':False,'start_unix_s':stamp,'end_unix_s':time.time(),'seconds':elapsed,'output_tok_s':8192/elapsed,'requests':result}
  with (p/'requests.jsonl').open('a') as f:f.write(json.dumps(row)+'\n')
  print(label,round(row['output_tok_s'],1),flush=True);time.sleep(2)
for label,source,case,n,out in [('baseline_text',corpus,'prose_1000',8,1024),('baseline_long',corpus,'prose_25000',4,512),('baseline_speed',corpus.with_name('speed_agents.json'),'speed',20,512)]:
 argv=[sys.executable,'benchmark/qwen38_spec/throughput.py','run','--url',url,'--corpus',str(source),'--case',case,'--requests',str(n),'--output-tokens',str(out),'--concurrency','4','8','--repeats','2' if label=='baseline_text' else '1','--label',label,'--output',str(p/label)]
 if case=='speed':argv+=['--natural-eos']
 with (p/(label+'.log')).open('x') as f:r=subprocess.run(argv,cwd=repo,stdout=f,stderr=subprocess.STDOUT)
 if r.returncode:raise RuntimeError(label)
 print('Completed',label,flush=True)
(p/'baseline.done').write_text('Baseline and counters complete\n')
