import concurrent.futures,json,pathlib,subprocess,sys,time
import requests
repo=pathlib.Path('/home/rah/sglang-V100');root=pathlib.Path('/home/rah/qwen38-runs/20261104-concurrent-core-audit');sys.path.insert(0,str(repo/'benchmark/qwen38_spec'))
from throughput import generate
from core_audit import Monitor
url='http://127.0.0.1:8082';corpus=json.loads(pathlib.Path('/home/rah/qwen38-runs/20261104-throughput/corpus.json').read_text())['cases']
(root/'server.json').write_text(json.dumps(requests.get(url+'/get_server_info',timeout=10).json(),indent=2));(root/'STATE.json').write_text(json.dumps({'stage':'capturing_live','controller_pid':__import__('os').getpid(),'production_stopped':False}))
def flush():
 r=requests.post(url+'/flush_cache',params={'timeout':30},timeout=120);r.raise_for_status()
 try:d=r.json()
 except ValueError:d=None
 if d is False or isinstance(d,dict) and d.get('success') is False:raise RuntimeError('Cache flush refused')
def batch(label,case,concurrency,tokens=1024,cache=False):
 selected=[c for c in corpus if c['source_id']==case][:concurrency]
 assert len(selected)==concurrency
 flush()
 if cache:
  with concurrent.futures.ThreadPoolExecutor(max_workers=concurrency) as e:list(e.map(lambda c:generate(url,c,512),selected))
 start=time.perf_counter();stamp=time.time()
 with concurrent.futures.ThreadPoolExecutor(max_workers=concurrency) as e:results=list(e.map(lambda c:generate(url,c,tokens),selected))
 elapsed=time.perf_counter()-start
 row={'label':label,'case':case,'concurrency':concurrency,'cached':cache,'start_unix_s':stamp,'end_unix_s':time.time(),'seconds':elapsed,'output_tok_s':sum(r['output_tokens'] for r in results)/elapsed,'requests':results}
 with (root/'requests.jsonl').open('a') as f:f.write(json.dumps(row)+'\n')
 print(json.dumps({k:v for k,v in row.items() if k!='requests'}),flush=True)
 return row
with Monitor(root/'nvml.jsonl'):
 batch('warmup','prose_1000',4,64)
 for repeat in range(2):
  for n in ([1,2,4] if repeat==0 else [4,2,1]):batch('untraced_'+str(repeat),'prose_1000',n,1024)
 for label,fields in [('dcgm_sm',[1001,1002,1003,1005,1009,1010,1011,1012]),('dcgm_tensor',[1001,1004,1005,1009,1010,1011,1012])]:
  with Monitor(root/(label+'.jsonl'),fields):
   time.sleep(3)
   for n in [1,2,4]:batch(label,'prose_25000',n,1024)
   time.sleep(2)
 subprocess.run(['dcgmi','profile','--pause'],check=True)
 try:
  for n in [1,4]:
   selected=[c for c in corpus if c['source_id']=='prose_8192'][:n];flush()
   with concurrent.futures.ThreadPoolExecutor(max_workers=n) as e:list(e.map(lambda c:generate(url,c,512),selected))
   d=root/('decode_trace_c'+str(n));d.mkdir()
   requests.post(url+'/start_profile',json={'output_dir':str(d),'activities':['CPU','GPU'],'with_stack':False,'record_shapes':False,'profile_prefix':'decode_c'+str(n)},timeout=120).raise_for_status()
   try:
    # Prefixes were primed outside the trace; do not flush inside this request.
    start=time.perf_counter();stamp=time.time()
    with concurrent.futures.ThreadPoolExecutor(max_workers=n) as e:results=list(e.map(lambda c:generate(url,c,192),selected))
    row={'label':'decode_trace','case':'prose_8192','concurrency':n,'cached':True,'diagnostic':True,'start_unix_s':stamp,'end_unix_s':time.time(),'seconds':time.perf_counter()-start,'requests':results};(d/'request.json').write_text(json.dumps(row))
   finally:requests.post(url+'/stop_profile',timeout=600).raise_for_status()
   print('Captured',d.name,flush=True)
  d=root/'prefill_trace';d.mkdir();flush()
  requests.post(url+'/start_profile',json={'output_dir':str(d),'activities':['CPU','GPU'],'with_stack':False,'record_shapes':False,'profile_prefix':'prefill'},timeout=120).raise_for_status()
  try:batch('prefill_trace','prose_70000',1,1)
  finally:requests.post(url+'/stop_profile',timeout=600).raise_for_status()
 finally:subprocess.run(['dcgmi','profile','--resume'],check=True)
(root/'STATE.json').write_text(json.dumps({'stage':'captured','production_stopped':False,'completed':True}));print('Capture complete',flush=True)
