import concurrent.futures,json,pathlib,sys,time
import requests
root=pathlib.Path('/home/rah/qwen38-runs/20261104-concurrent-core-audit');sys.path.insert(0,'/home/rah/sglang-V100/benchmark/qwen38_spec')
from core_audit import Monitor
from throughput import generate
end=time.monotonic()+3600
while not (root/'mtp3_c8.done').exists():
 if time.monotonic()>end:raise TimeoutError('4K candidate did not complete')
 time.sleep(2)
url='http://127.0.0.1:8083';corpus=json.loads(pathlib.Path('/home/rah/qwen38-runs/20261104-throughput/corpus.json').read_text())['cases']
for group,fields in [('sm',[1001,1002,1003,1005,1009,1010,1011,1012]),('tensor',[1001,1004,1005,1009,1010,1011,1012])]:
 label='mtp3_c8_dcgm_'+group
 with Monitor(root/(label+'_nvml.jsonl')),Monitor(root/(label+'.jsonl'),fields):
  time.sleep(3)
  for case,n,tokens in [('prose_25000',1,1024),('prose_1000',4,2048),('prose_1000',8,2048)]:
   requests.post(url+'/flush_cache',params={'timeout':30},timeout=120).raise_for_status();selected=[c for c in corpus if c['source_id']==case][:n];stamp=time.time();start=time.perf_counter()
   with concurrent.futures.ThreadPoolExecutor(max_workers=n) as e:result=list(e.map(lambda c:generate(url,c,tokens),selected))
   elapsed=time.perf_counter()-start;row={'label':label,'case':case,'concurrency':n,'cached':False,'start_unix_s':stamp,'end_unix_s':time.time(),'seconds':elapsed,'output_tok_s':sum(r['output_tokens'] for r in result)/elapsed,'requests':result}
   with (root/'requests.jsonl').open('a') as f:f.write(json.dumps(row)+'\n')
   print(label,case,round(row['output_tok_s'],2),flush=True)
  time.sleep(2)
(root/'eight_counters.done').write_text('Candidate counters complete\n')
