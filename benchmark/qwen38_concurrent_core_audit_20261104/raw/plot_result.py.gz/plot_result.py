import json,pathlib,statistics
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
p=pathlib.Path('/home/rah/sglang-V100/benchmark/qwen38_concurrent_core_audit_20261104');d=json.loads((p/'summary.json').read_text());plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'axes.spines.top':False,'axes.spines.right':False,'svg.fonttype':'none'})
fig,axes=plt.subplots(1,3,figsize=(12,4),layout='constrained')
for ax,kind,title in zip(axes,['text','speed','long'],['Eight-client fixed text','Eight-client mixed workloads','Four independent 25K prompts']):
 if kind=='long':
  before=statistics.mean(d['comparisons'][kind][str(c)]['baseline_output_tok_s'] for c in [4,8]);after=statistics.mean(d['comparisons'][kind][str(c)]['candidate_output_tok_s'] for c in [4,8])
 else:before=d['comparisons'][kind]['8']['baseline_output_tok_s'];after=d['comparisons'][kind]['8']['candidate_output_tok_s']
 ax.bar([0,1],[before,after],color=['#60758c','#15817e'],width=.58);ax.set_xticks([0,1],['v5.4','v5.5']);ax.set_ylim(0,after*1.22);ax.set_title(title);ax.set_ylabel('Aggregate output tokens / second')
 for i,v in enumerate([before,after]):ax.text(i,v+after*.025,f'{v:.1f}',ha='center')
 ax.text(.5,after*1.12,f'+{(after/before-1)*100:.1f}%',ha='center',weight='bold',color='#116562')
fig.suptitle('Qwen3.8 Flash Next · 4× V100 · end-to-end throughput',fontsize=14)
fig.text(.01,-.035,'Includes prefill and queueing. Fixed text: 2 batches/concurrency. SPEED: 1 natural-EOS batch. Long prompts: 2 batches of 4 requests.',fontsize=9)
fig.savefig(p/'throughput_gain.svg',bbox_inches='tight');fig.savefig('/home/rah/qwen38-runs/20261104-concurrent-core-audit/throughput_gain.png',dpi=140,bbox_inches='tight')
