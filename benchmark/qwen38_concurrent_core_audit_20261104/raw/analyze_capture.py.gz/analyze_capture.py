import collections,gzip,json,pathlib,statistics,sys
root=pathlib.Path('/home/rah/qwen38-runs/20261104-concurrent-core-audit');sys.path.insert(0,'/home/rah/sglang-V100/benchmark/qwen38_spec')
from analyze_core_audit import kernel_category
from analyze_profile import union_us
rows=[json.loads(s) for s in (root/'requests.jsonl').read_text().splitlines() if s.strip()]
nvml=[json.loads(s) for s in (root/'nvml.jsonl').read_text().splitlines() if s.strip()]
for path in root.glob('*dcgm*_nvml.jsonl'):
 nvml.extend(json.loads(s) for s in path.read_text().splitlines() if s.strip())
counters={}
for label in ['dcgm_sm','dcgm_tensor','dcgm_sm_c4short','dcgm_tensor_c4short','mtp3_c8_dcgm_sm','mtp3_c8_dcgm_tensor']:
 if not (root/(label+'.jsonl')).exists():continue
 samples=[]
 for s in (root/(label+'.jsonl')).read_text().splitlines():
  r=json.loads(s);parts=r['raw'].split()
  if len(parts)!=2+len(r['fields']) or parts[0]!='GPU':continue
  try:samples.append({'time':r['unix_s'],'gpu':int(parts[1]),'values':dict(zip(r['fields'],map(float,parts[2:])))})
  except ValueError:pass
 counters[label]=samples
result={'requests':[],'traces':{},'notes':['DCGM fractions measure activity, not fraction of peak FLOPS or GB/s.','Conservative 2.2-second guards exclude counter samples crossing request phases.','Prefill window ends at the first answer token across clients; later mixed prefill/decode is excluded.','Decode window starts only after every client has an answer token and ends when the first completes.','Trace kernel durations are diagnostic and can overlap; traced idle is not an untraced budget.']}
for r in rows:
 if r['label']=='warmup':continue
 q=r['requests'];first=min(x['start_unix_s']+x['ttft_s'] for x in q);last=max(x['start_unix_s']+x['ttft_s'] for x in q);end=min(x['start_unix_s']+x['e2e_s'] for x in q)
 out={k:v for k,v in r.items() if k!='requests'};out['phases']={}
 for phase,start,stop in [('initial_prefill',r['start_unix_s'],first),('all_clients_decode',last,end)]:
  guard=2.2;picked=[s for s in nvml if start+guard<s['unix_s']<stop-guard]
  hardware={}
  if picked:
   hardware={'sample_count':len(picked),'power_w':[statistics.mean(s['devices'][i]['power_w'] for s in picked) for i in range(4)],'sm_mhz':[statistics.median(s['devices'][i]['sm_mhz'] for s in picked) for i in range(4)],'gpu_busy_pct':statistics.mean(d['gpu_percent'] for s in picked for d in s['devices']),'throttle_flags':sorted(set(d['throttle_reasons'] for s in picked for d in s['devices']))}
  cp=[s for s in counters.get(r['label'],[]) if start+guard<s['time']<stop-guard]
  fields=sorted(set(k for s in cp for k in s['values']))
  counter={str(k):statistics.mean(s['values'][k] for s in cp if k in s['values']) for k in fields}
  out['phases'][phase]={'duration_s':stop-start,'nvml':hardware,'dcgm_sample_count':len(cp),'dcgm_mean':counter}
 result['requests'].append(out)
previous = root/'audit_summary.json'
if previous.exists():result['traces']=json.loads(previous.read_text()).get('traces',{})
for d in ['decode_trace_c1','decode_trace_c4','prefill_trace']:
 if d in result['traces']:continue
 directory=root/d
 for path in sorted(directory.glob('*TP-0.trace.json.gz')):
  with gzip.open(path,'rt') as f:t=json.load(f)
  g=[e for e in t['traceEvents'] if e.get('ph')=='X' and e.get('cat') in ('kernel','gpu_memcpy','gpu_memset')]
  sums=collections.Counter();names=collections.Counter();counts=collections.Counter()
  for e in g:sums[kernel_category(e['name'])]+=e['dur']/1000;names[e['name']]+=e['dur']/1000;counts[kernel_category(e['name'])]+=1
  intervals=[(e['ts'],e['ts']+e['dur']) for e in g];span=max(b for a,b in intervals)-min(a for a,b in intervals)
  result['traces'][d]={'source':str(path),'span_ms':span/1000,'busy_ms':union_us(intervals)/1000,'kernel_ms':dict(sums),'kernel_count':dict(counts),'top_kernels_ms':dict(names.most_common(35)),'trace_idle_fraction':1-union_us(intervals)/span}
  print(d,dict(sums),flush=True)
(root/'audit_summary.json').write_text(json.dumps(result,indent=2)+'\n')
for r in result['requests']:
 if not r['label'].startswith('dcgm'):continue
 print(r['label'],r['concurrency'],[(p,[(k,round(v,3)) for k,v in x['dcgm_mean'].items() if int(k)<1009]) for p,x in r['phases'].items()])
