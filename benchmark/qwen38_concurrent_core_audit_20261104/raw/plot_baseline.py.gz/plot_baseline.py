import json,pathlib,statistics
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
root=pathlib.Path('/home/rah/qwen38-runs/20261104-concurrent-core-audit')
d=json.loads((root/'audit_summary.json').read_text())
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'axes.spines.top':False,'axes.spines.right':False,'svg.fonttype':'none'})
fig,axes=plt.subplots(1,3,figsize=(15,4.6),layout='constrained')
counts=[1,2,4];throughput=[];power=[]
for c in counts:
 rows=[r for r in d['requests'] if r['label'].startswith('untraced') and r['concurrency']==c]
 throughput.append(statistics.mean(r['output_tok_s'] for r in rows))
 power.append(statistics.mean(v for r in rows for v in r['phases']['all_clients_decode']['nvml']['power_w']))
ax=axes[0];ax.bar(range(3),throughput,color='#157f83',width=.58);ax.set_xticks(range(3),['1 agent','2 agents','4 agents']);ax.set_ylabel('Completed output tokens / second');ax.set_title('More concurrent work raises throughput');ax.set_ylim(0,300)
for i,t in enumerate(throughput):ax.text(i,t+5,f'{t:.0f}',ha='center')
ax=axes[1];ax.bar(range(3),power,color='#546a9c',width=.58);ax.axhline(300,color='#a34e30',ls='--',label='300 W limit');ax.set_xticks(range(3),['1 agent','2 agents','4 agents']);ax.set_ylabel('Average power per GPU (W)');ax.set_ylim(0,330);ax.set_title('Decode stays below the power limit');ax.legend(loc='upper left',frameon=False)
for i,t in enumerate(power):ax.text(i,t+5,f'{t:.0f} W',ha='center')
def counters(label,concurrency,phase):return next(r for r in d['requests'] if r['label']==label and r['concurrency']==concurrency)['phases'][phase]['dcgm_mean']
p=counters('dcgm_sm',1,'initial_prefill');pt=counters('dcgm_tensor',1,'initial_prefill');c=counters('dcgm_sm_c4short',4,'all_clients_decode');ct=counters('dcgm_tensor_c4short',4,'all_clients_decode')
a=[p['1002'],p['1003'],pt['1004'],p['1005']];b=[c['1002'],c['1003'],ct['1004'],c['1005']]
x=np.arange(4);ax=axes[2];ax.bar(x-.18,np.array(a)*100,.36,label='Prefill, 25K prompt',color='#d18c39');ax.bar(x+.18,np.array(b)*100,.36,label='Decode, 4×1K prompts',color='#157f83');ax.set_xticks(x,['SM active','Occupancy','Tensor pipe','DRAM active'],rotation=20,ha='right');ax.set_ylabel('Activity (%)');ax.set_ylim(0,100);ax.set_title('Busy engines leave arithmetic capacity unused');ax.legend(frameon=False,fontsize=8)
fig.suptitle('Qwen3.8 Flash Next · 4× V100 SXM2 32 GB · v5.4 baseline',fontsize=14)
fig.text(.01,-.055,'Left/middle: matched 1K prompts, 1,024 output tokens, two runs. Power uses steady decode windows. Right: separate DCGM passes; activity is not % of peak FLOP/s.',fontsize=9)
fig.savefig(root/'core_activity.svg',bbox_inches='tight');fig.savefig(root/'core_activity.png',dpi=140,bbox_inches='tight')
print('Saved core_activity.svg and .png')
