import json,pathlib,sys,time
import requests
p=pathlib.Path('/home/rah/qwen38-runs/20261104-concurrent-core-audit');sys.path.insert(0,'/home/rah/sglang-V100/benchmark/qwen38_spec')
from throughput import generate
end=time.monotonic()+2400
while not (p/'eight_counters.done').exists():
 if time.monotonic()>end:raise TimeoutError('Counter pass unfinished')
 time.sleep(2)
case=next(c for c in json.loads(pathlib.Path('/home/rah/qwen38-runs/20261104-throughput/corpus.json').read_text())['cases'] if c['id']=='prose_1000_agent0');rows=[]
for repeat in range(2):
 requests.post('http://127.0.0.1:8083/flush_cache',params={'timeout':30},timeout=120).raise_for_status();r=generate('http://127.0.0.1:8083',case,1024);r['repeat']=repeat;rows.append(r);print('single_e2e_tok_s',1024/r['e2e_s'],'decode_tok_s',r['decode_tok_s'],flush=True)
(p/'mtp3_c8_single.json').write_text(json.dumps(rows,indent=2)+'\n');(p/'single.done').write_text('Single-client check complete\n')
