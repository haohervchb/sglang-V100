# 2026-11-11 Flash-Next review notes (working draft)

Source of the decode breakdown: v5.4 diagnostic traces in
`/home/rah/qwen38-runs/20261104-concurrent-core-audit/decode_trace_c{1,4}` (rank 0).
Traced timings are inflated (~27 ms traced vs ~21.4 ms untraced cycle at C1).

## C1 verify (M = 4 rows), per layer critical path, traced
GDN layer ~280 us: HC 2x(norm+down+up)+2 combines ~72 us, GDN attention ~72 us,
MoE (router, top-k, gate_up, reduce, down, reduce, add) ~97 us, 2 all-reduces ~10 us, gaps ~25 us.
QSA layer ~590 us: attention sublayer ~380 us, of which ~250 us is the indexer's eager chain
(~55 small kernels) on the alt stream that the main stream waits for.

## Finding 1 (fixed in working tree): fused QSA indexer prep silently disabled
`MRotaryEmbedding.forward_triton` -> `_match_cos_sin_cache_dtype(query)` converts the shared
cos/sin cache to FP16 on the first attention forward. `QSAIndexer._use_fused_prep` required an
FP32 cache, so every captured graph (verify, draft extend, draft decode) and every prefill used the
eager chain (GemmaRMSNorm, index gathers, rope, cat, average pool, index_put).
Fix: fused kernels templated on cache dtype (fp32 or storage dtype). Eager RoPE rounds cos/sin
to FP16 anyway, so outputs are bit-identical (15 V100 parity cases).

## C4 verify (M = 16 rows): 30.2 ms traced
cuBLAS/CUTLASS dense+HC GEMMs ~9.9 ms at 110-480 GB/s (custom kernels only cover M = 2/4),
MoE ~11.4 ms (per-route, no expert dedup), HC mix falls back to torch.compile for M > 4.
Bytes moved by the dense GEMMs per verify ~3.1 GB per GPU -> ~4.2 ms at 750 GB/s.

## A/B result (sequential arms, same host, office profile on port 8083, 2 repeats each)
| Workload | Baseline | Fix | Change |
| --- | ---: | ---: | ---: |
| Prose 1K/1024, C1 | 114.4 tok/s (decode 118.4) | 129.5 (decode 134.4) | +13.2% |
| Prose C4 | 250.0 | 273.3 | +9.3% |
| Prose C8 | 359.1 | 378.4 | +5.4% |
| Copy-edit 8K/512, C1 | 102.2 (decode 182.0) | 112.6 (decode 206.7) | +10.1% |
| Copy-edit C4 | 150.3 | 161.8 | +7.7% |
Acceptance unchanged (2.56/2.55/2.58 prose, 4.00 code). Output hashes: C1 prose 8/8, C8 16/16, code 32/32
identical across arms; C4 prose differs where the baseline also disagrees with itself across repeats.
Post-fix trace: qsa_index_q_prep_kernel 7.5 us + qsa_index_k_compress_kernel 7.6 us per QSA layer,
kernels per verify 1,893 -> 1,444.

## Functional gates with the fix (validate_arm.sh fix)
checks 8/8 (incl. 262K retrieval, oversized rejection), tools pass, shared document C8 pass
(cached 30,720-32,384 per answer), multimodal 11/12 with only the known 'V10 CHECK 4827' OCR miss.

## Full bundle (worktree /home/rah/sglang-V100-bundle, branch qwen38-perf-bundle-20261111)
Fix + F07 (GDN BV tile for N>1) + F08 (ratio-3 Triton split) + F14 (q/k norm off the indexer
stream) + F18 (QSA metadata tiling >8 rows) + F28 (MTP RoPE via Triton, draft-only numerics) +
F32 (topk=1 draft chain constants) + fused two-kernel MoE decode (tournament 'vectorized').
| Workload | Baseline | Fix | Bundle |
| --- | ---: | ---: | ---: |
| Prose C1 | 114.4 (dec 118.4) | 129.5 (134.4) | 143.3 (149.1) |
| Prose C4 | 250.0 | 273.3 | 349.4 |
| Prose C8 | 359.1 | 378.4 | 510.3 |
| Copy-edit C1 | 102.2 (dec 182.0) | 112.6 (206.7) | 118.6 (228.3) |
| Copy-edit C4 | 150.3 | 161.8 | 176.4 |
Acceptance 2.54/2.55/2.57 prose (vs 2.56/2.55/2.58), 4.00 code. Copy-edit hashes 32/32 identical
across all arms; prose C1 0/16 identical to fix-only (F28 changes drafts -> acceptance pattern),
C8 12/16. Confirming arm without F28 in progress.
Bundle C1 trace: verify 13.3 ms traced (fix-only 15.1), MoE 43.7 us/layer (was ~72).

## Bit-identity bisection (C1 prose, 4 x 1024 tokens, vs fix-only `candidate`), resumed 15:38 after session loss
| Arm | Changes on (besides fix + F07 + F18) | Identical | Note |
| --- | --- | ---: | --- |
| q_alloff | none | 4/4 | toggles sound, quick test deterministic |
| q_moe | fused MoE decode | 4/4 | bitwise in serving |
| q_f32 | topk=1 chain constants | 4/4 | bitwise |
| q_f14 / q_f14b | F14 all QSA layers | 0/4 (q_f14 == q_f14b 4/4) | deterministic change |
| q_f14t | F14 target layers only | 4/4 | bitwise |
| q_f14d | F14 MTP draft layer only | 0/4 (== q_f14 4/4) | draft-side numerics change |
| q_f08 | F08 ratio-3 Triton split | 0/4 | prefill-only at C1; repeat + logprob probe pending |
Divergence starts at the same fragile tokens across arms (e.g. agent0 char 1608): GDN verify carries fp32
state between rows while commits are fp16, so any draft-token change alters target numerics. Bitwise gate
therefore only applies to changes that leave draft tokens untouched; draft-side changes need acceptance gates.
Decision: F14 restricted to target layers (not is_nextn).

## Untraced C1 GPU activity (DCGM 100 ms, q_f14b config)
GR_ENGINE_ACTIVE 0.975-0.980, SM_ACTIVE ~0.65, DRAM_ACTIVE ~0.36 on all GPUs during decode.
=> host window (F03/F04/F33) worth <= ~2% at C1; traced 33% GPU idle was CUPTI/stack-tracing inflation.
C1 is kernel-latency bound: next levers are HC down/up (3.05 ms of 13.3 ms traced verify), MoE routing top-10
(7.3 us x 48 per verify), small GEMM latency floors.
Follow-ups (16:00-16:22):
- q_f08b == q_f08 (deterministic). Logprob probe (prefill last-8 input logprobs + 64 decode tokens):
  bitwise identical to control for F08 and F14-draft -> numeric deviation starts later in decode.
- Layout probes (4 KB dummy alloc in QSA self_attention, no compute change): q_padd (draft) and q_padt
  (target) both 4/4 identical -> graph-pool layout is not what F08/F14-draft perturb.
- Open: F08 is a pure copy at C1 (prefill only, bitwise) yet changes late-decode outputs deterministically.
  Remaining hypothesis: an eager (non-graph) decode-time read of uninitialized caching-allocator memory
  whose contents depend on prefill's allocation pattern. Not pursued further today.
- Decision: drop F08 from the bitwise bundle (~1% at C4/C8 forgone), keep F14 target-only.
- Mamba-track test: q_mt_ctrl (interval 4096) == control (interval 256) over 1024 tokens of logprobs; q_mt_f08
  still first deviates at output token 272 (total length 1281) with identical values -> tracking is not
  involved. F08's late-decode effect remains unexplained (first logprob deviation at ctx ~1281 for agent0).
- Microbenchmarks (cold weights, graph replay): warp-select MoE top-10 is bitwise (3420 rows incl. ties/NaN)
  but not faster (5.0 vs 4.8 us/launch); HC down/up at M=2/4: no bitwise launch reshaping beats the
  originals by more than ~5% (down 11.9 us, up 15.2 us at M=4). Both dropped.

## Final bundle measurement `final1` (finished 16:59, just before a ~17:05 power outage)
Tree = bundle worktree diff, verified identical to final1_source.diff; no QDBG toggles.
Contents: fix + F07 + F14 (target layers only) + F18 + F32 + fused MoE decode. F08 and F28 dropped.
| Workload | Baseline | Fix | final1 | vs baseline |
| --- | ---: | ---: | ---: | ---: |
| Prose C1 | 114.4 (dec 118.4) | 129.5 (134.4) | 141.2 (146.7) | +23.4% |
| Prose C4 | 250.0 | 273.3 | 336.5 | +34.6% |
| Prose C8 | 359.1 | 378.4 | 497.4 | +38.5% |
| Copy-edit C1 | 102.2 (dec 182.0) | 112.6 (206.7) | 116.4 (225.1) | +13.9% |
| Copy-edit C4 | 150.3 | 161.8 | 172.9 | +15.0% |
Hashes vs fix-only `candidate`: prose C1 16/16, C8 16/16, code C1 16/16, C4 16/16; prose C4 1/16, where
candidate is itself only 2/16 repeat-stable (batch-order nondeterminism) -> bitwise gate passes.
Acceptance 2.56/2.56/2.58 prose, 4.00 code (unchanged).
Next: functional gates on the bundle (validate_arm.sh with REPO=bundle) -> `bundle_final.validated`.
Functional gates on the bundle (`bundle_final`, after the outage): checks 8/8 PASS, tools PASS, shared C8 PASS,
multimodal 11/12 with only the known 'V10 CHECK 4827' OCR miss (identical text to fix-only) -> same as fix arm.
Bundle is ready to commit.
