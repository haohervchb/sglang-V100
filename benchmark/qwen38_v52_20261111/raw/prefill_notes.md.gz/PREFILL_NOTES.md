# Prefill push vs 1Cat v1.5.2 (2026-11-11 evening)
Scope approved: items 1, 2, 4, 5 of ../20261111-indexer-fp16-cache/prefill_1cat_v152_ideas.md (not 3, TurboMind MoE).
Worktree /home/rah/sglang-V100-prefill, branch qwen38-prefill-20261111 (from bundle 52996dfe53).
Harness: arm.sh / arm2.sh (adds GPU memory log), prefill_bench.py (fresh prose 8K/25K/70K/160K, flush between,
max_new_tokens=1, records first-token + last-4 input logprobs for parity).

## Changes in progress (uncommitted)
- Item 1: key-split grid for the TileLang indexer scorer (mqa.py), SGLANG_ENABLE_QSA_MQA_KEY_SPLIT (default on). Bitwise by construction.
- Item 5a: TP row split of indexer prefill scoring + top-k with all_gather of block ids (qsa_indexer.py),
  SGLANG_ENABLE_QSA_PREFILL_TP_SPLIT (default on). Indexer is ReplicatedLinear -> exact.
- Item 2a: PLE prefill temporaries trimmed bit-exactly (conv input built in place, early dels, in-place add/mask, silu_).
- Item 2d: SGLANG_CHUNKED_PREFILL_CACHE_ALIGN (default 0): final chunk > align cut at the last multiple.
- Item 4: grouped Page4 QSA prefill for any chunk <= 8192 rows (ragged rows front-padded), capacity workspace.
  Without this, 4K chunks would silently fall back to the native kernel for every QSA layer.

## Results
### Baseline (bundle 52996dfe53, 2K chunks) fresh prose TTFT
8K 2.06 s (3,975 tok/s) | 25K 6.08 s (4,112) | 70K 17.53 s (3,994) | 160K 43.0 s (3,720). Repeats within 0.3%.
Trace rank 0, 3 chunks of 2048 (per chunk): early (70K prompt, ctx<8K) 339 ms; late (160K prompt, ctx ~125K) 389 ms.
Late per chunk: Marlin MoE 97 ms + sum_reduce 5; dense GEMMs ~75; grouped Page4 QSA attention 59 (named
flash_attention_grouped_verify_e5m2_partial_kernel); TileLang indexer scorer ('kernel_kernel') 35 (2.3 early);
fast_topk 8.7 (1.8 early); TileLang 'main_kernel' 21; all-reduce 18; HC combine 13; HC mix (triton fused) 8.7; GemmaRMSNorm 7.3.
=> indexer scorer+topk grow from ~4 to ~44 ms/chunk between 8K and 125K context: the context-dependent part of the gap.
### p2k (items 1+5a+2a+4 at 2K chunks, split threshold rows*keys >= 4M)
8K 2.135 (+3.6% slower) | 25K 6.33 avg (+4%) | 70K 17.83 (+1.7%) | 160K 40.51 (-5.8%).
Trace: late-chunk kernel sum -33 ms/chunk (scorer 35->4 ms, topk 8.7->2.5) but GPU idle +6 ms/chunk at all contexts.
Unit: key-split scorer bitwise in 6 cases, 2.2-4.5x at 32K-62K keys; grouped QSA 13/13 incl. ragged 13 and 1003 rows.
Gap analysis: baseline already has ~23 ms/chunk of GPU idle; per-QSA-layer DtoH syncs (positions.max().item() for
RoPE cache length, sequence_lengths.tolist() in get_prefill_mqa_inputs) drain the launch queue. The all-gather adds more.
Fix (p2k_b): cache both host values once per forward on QSAIndexerMetadata.host_values; TP split only at
>= 8192 compressed keys (~32K ctx) and >= 1024 rows.
### p4k (same code as p2k, 4096 chunks + SGLANG_CHUNKED_PREFILL_CACHE_ALIGN=2048)
8K 1.816 s (-11.9%) | 25K 5.330 (-12.4%) | 70K 15.15 (-13.6%) | 160K 35.20 (-18.2%) vs baseline. Repeats within 0.2%.
Peak GPU memory 29.78 GB (p2k 29.15) of 32.5, KV pool unchanged at 277,280 tokens.
Trace per 4K chunk (early): 598 ms vs 2 x 339 for base; MoE per token -11%; fixed per-chunk gaps amortized.
### p2k_b (sync cache + TP split only >= 8192 keys & >= 1024 rows), 2K chunks
8K 2.018 (-2.2%) | 25K 5.951 (-2.2%) | 70K 16.95 (-3.3%) | 160K 39.43 (-8.4%) vs baseline.
### Parity probe (prompts truncated to 2048 multiples; 32 greedy tokens; last-64 input logprobs)
Generated tokens 32/32 identical in every arm (p2k, p4k, p2k_b vs base_par); output logprobs differ ~1e-3.
Input logprobs differ by up to 2-9 nats on improbable filler tokens (-8..-16) - also between p2k and p2k_b on a
prompt where p2k_b never splits. Suspect input-logprob readout is not run-to-run deterministic: base_par2 (baseline
code, fresh server) queued to check before drawing conclusions.
### p4k_b (final code incl. PLE edits, 4K): 8K 1.791 (-13.1%) | 25K 5.264 (-13.4%) | 70K 14.95 (-14.7%) | 160K 34.78 (-19.2%)
GPU idle per 3x4K chunks 72 -> 40 ms after the sync fix.
### Gates on the 4K config (with PLE edits)
fv4k: checks 8/8, tools, shared C8 PASS (cached 30,720-32,384), mm 11/12 (known OCR). m4k vs final1: prose C1 +0.8%,
C4 +0.6%, C8 0%, code C1 +8.2%, C4 +12.2% (TTFT 2.13->1.81, 5.71->5.22); acceptance equal; hashes prose C1 0/16,
C8 16/16, code 32/32.
base_par2 vs base_par (same baseline code, fresh servers): input logprobs also differ up to 8 nats -> the input-logprob
drift in the parity probe is run-to-run behaviour of the baseline, not caused by these changes.
q_nople (all changes except the PLE edits, 4K): prose C1 4/4 hashes identical to final1, same acceptance and speed.
=> PLE edits change decode outputs (numerics or allocation-sensitivity); dropped (only one PLE layer; memory not needed at 4K).
Launcher: 4096 chunks + SGLANG_CHUNKED_PREFILL_CACHE_ALIGN=2048 by default. Final gates on the commit tree: final_pf, final_fv.
### Final (committed 28749dcc1a on qwen38-prefill-20261111; PLE edits excluded)
Prefill: 8K 1.84 (-11%) | 25K 5.34 (-12%) | 70K 15.10 (-14%) | 160K 35.0 (-19%). Peak 29.9 GB.
final_fv: checks 8/8, tools, shared C8 (30,720-32,384 cached), mm 11/12 known OCR.
final_m vs final1: prose C1 +0.5% (16/16 hashes), C4 +0.6% (3/16; bundle repeat-stable 2/16, new 16/16), C8 +1.3% (16/16),
code C1 +8.7% (16/16), C4 +12.2% (16/16); acceptance unchanged.
Not done: item 3 (user declined), item 5b HC row ownership (numerics change, not needed at 4K).
