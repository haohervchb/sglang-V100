import gzip,hashlib,json,pathlib,re,statistics
root=pathlib.Path(__file__).resolve().parent
out=pathlib.Path('/home/rah/sglang-V100/benchmark/qwen38_docker_v5_20261105')
assert (root/'validation.done').exists(), 'Validation/restoration is not complete'
(out/'raw').mkdir(parents=True,exist_ok=True)

def read(name):
    return json.loads((root/name).read_text())
def digest(data):
    return hashlib.sha256(data).hexdigest()
def scrub(value):
    if isinstance(value,list):
        return [scrub(v) for v in value]
    if isinstance(value,dict):
        return {k:scrub(v) for k,v in value.items() if k not in ['output_text','api_key','admin_api_key','ssl_keyfile_password','HF_TOKEN']}
    return value

runs={}
for name in ['host_text','container_text','container_speed']:
    rows=read(name+'/summary.json')
    assert all(not r['errors'] and r['completed']==r['requested'] for r in rows)
    runs[name]={str(c):{'batches':len([r for r in rows if r['concurrency']==c]),
                       'aggregate_tok_s':statistics.mean(r['output_tok_s'] for r in rows if r['concurrency']==c),
                       'median_decode_tok_s':statistics.mean(r['median_decode_tok_s'] for r in rows if r['concurrency']==c)}
                for c in sorted(set(r['concurrency'] for r in rows))}
native=(root/'container_native_tests.log').read_text()
match=re.search(r'(\d+) passed',native)
assert match and ' skipped' not in native
image=json.loads((root/'container_images/results.jsonl').read_text().splitlines()[0])
queue=read('container_queue/summary.json')
mm=read('container_mm_results.json')
shared=read('container_shared.json')
host=read('host_live_validation.json')
summary={'image':read('tested_image.json'),'runs':runs,'native_tests_passed':int(match.group(1)),
         'text_checks':read('container_checks.json')['passed'],
         'tool_arguments':read('container_tools.json')['tool_arguments'],
         'tool_result':read('container_tools.json')['tool_result'],
         'multimodal_passed':sum(c['passed'] for c in mm['cases']),
         'multimodal_total':len(mm['cases']),'multimodal_failures':[c['name'] for c in mm['cases'] if not c['passed']],
         'image_32':image,'queue':queue,'shared_document':shared,
         'host_restored':{'passed':host['passed'],'image_seconds':host['image_result']['seconds'],
                          'gpu0_min_free_mib':host['min_free_mib'][0],'health':host['health_after']}}
(out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
manifest={}
names=['cold_start.json','package_evidence.py','native_provenance.json','build_candidate.log','build_release.log','build_tests.log','launcher_checks.json',
       'container_native_tests.log','container_checks.json','container_tools.json','container_shared.json',
       'container_mm_results.json','container_server.json','container_profile_flags.json','container_inspect.json',
       'container_server.log','host_restored.json','host_runtime_env.json','host_live_validation.json',
       'host_live_memory.json','image_manifest.json','image_cpu_checks.json','tested_image.json','jit_volume_before.json',
       'validate_container.py','prepare_validation.py','check_host_live.py']
for name in ['host_text','container_text','container_speed','container_images','container_queue']:
    names.extend(str(p.relative_to(root)) for p in (root/name).glob('*.json*'))
for name in names:
    path=root/name
    if not path.exists():continue
    original=path.read_bytes();data=original
    if path.suffix=='.json':data=(json.dumps(scrub(json.loads(original)),indent=2)+'\n').encode()
    elif path.suffix=='.jsonl':data=(''.join(json.dumps(scrub(json.loads(line)))+'\n' for line in original.decode().splitlines())).encode()
    archived=gzip.compress(data,mtime=0);dest=out/'raw'/(name.replace('/','_')+'.gz');dest.write_bytes(archived)
    manifest[dest.name]={'source':name,'source_sha256':digest(original),'archive_sha256':digest(archived),'sanitized':data!=original}
(out/'metadata.json').write_text(json.dumps({'model':'RadixArk/Qwen3.8-Flash-Next-NVFP4','revision':'7b719225242aacd3dbd3f9407468c2ee9a9d2594','raw_artifacts':manifest},indent=2)+'\n')
table=[]
for c in ['1','4','8']:
    a=runs['host_text'][c]['aggregate_tok_s'];b=runs['container_text'][c]['aggregate_tok_s']
    table.append(f'| C{c} | {a:.1f} | {b:.1f} | {(b/a-1)*100:+.1f}% |')
report=f"""# Balanced Flash-Next Docker v5

Docker v5 packages the balanced native MTP-3/4 profile used by the office host.
The standard start command is now `bash scripts/qwen38.sh`; the image itself
also defaults to this profile. Model/kernel arguments are in the serving
scripts. The launcher manages GPU access, cache volumes and container lifecycle.

The profile retains TP4 on four V100 SXM2 32 GB GPUs, FP16 KV, eight request
slots, 2K prefill, 277,280 shared KV tokens, 48 Mamba slots and 262K context.
CPU image preprocessing and the native vision backend are enabled. Wider MTP,
adaptive speculation and the three C1–C4 experimental flags remain off.

## Packaging

The image inherits the digest-pinned v4 CUDA 12.8 / PyTorch 2.9.1 SM70 runtime.
Its TurboMind binary matches the host. Patched grouped-QSA and native vision
libraries are built inside the image from pinned, attributed sources; host
shared libraries are excluded. The additional vision setup patch only permits
building without a visible GPU. It changes no CUDA kernel arithmetic.

The generic Docker entrypoint still accepts explicit commands and `sglang serve`
arguments. The default command selects the balanced profile. Model weights are
external to the image, and model/JIT caches persist across recreate operations.

Runtime source revision tested: `{summary['image']['revision']}`.
Image tested: `{summary['image']['id']}`.
Pytest was added in a separate test-only image; its runtime layers are identical
to the production image. GPU tests mounted only the test files, with no host
runtime source or native binaries. The published release is checked to retain
these exact runtime filesystem layers when updating its source-revision label
to include the evidence commit.

## Validation

- {summary['native_tests_passed']} grouped-QSA/vision GPU tests passed, including masked
  unused KV pages, graph replay, ragged images and 72-wide head scaling.
- All text checks passed, including 262K retrieval and oversized-input recovery.
- Tool calls and retained shared-document prefix reuse passed, with at least 30,720 cached tokens per answer.
- Multimodal: {summary['multimodal_passed']}/{summary['multimodal_total']}, retaining the same known OCR miss.
- The 32-image request passed in {image['seconds']:.2f} seconds.
- All {queue['completed']}/{queue['expected']} growing-document requests passed in
  {queue['seconds']:.2f} seconds; GPU 0 retained at least {queue['min_free_mib'][0]:.1f} MiB free.
- Host port 8082 was restored afterward. Parallel text, streaming and 32 images
  passed; final health was HTTP {host['health_after']}.

The container used an already populated model cache and the JIT-volume state
recorded in `jit_volume_before.json` (the named volume did not yet exist).
Logged readiness took about 19 minutes, including cached-weight loading and
first-use kernel compilation. Later starts reuse the compiled kernels.
This did not repeat the v4 test that
downloaded every model shard into an empty host cache.

## Throughput control

Cold 1K-input / 1,024-output-token prose, eight requests per batch. Host uses one
batch per concurrency; Docker uses two, reversing concurrency order in the
second pass. Rates include prefill and queueing. This sequential comparison is
a packaging regression check, not a claim of a new optimization.

| Clients | Host output tok/s | Docker output tok/s | Difference |
| --- | ---: | ---: | ---: |
{chr(10).join(table)}

The 20-case natural-EOS SPEED screen measured
{runs['container_speed']['8']['aggregate_tok_s']:.1f} aggregate output tok/s at C8.
Output lengths vary in that screen. See the raw request records for token
counts, acceptance, TTFT, output hashes and memory. Generated output prose is
omitted from the public archive.

[summary.json](summary.json) and [metadata.json](metadata.json) retain the
measurements, source/build hashes, configurations and validation logs. The
original run directory is `{root}`.
"""
(out/'README.md').write_text(report)
print('Packaged',len(manifest),'artifacts')

