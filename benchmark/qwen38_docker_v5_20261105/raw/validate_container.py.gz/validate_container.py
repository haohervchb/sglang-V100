import json, os, pathlib, subprocess, sys, time
import requests

root=pathlib.Path(__file__).resolve().parent
repo=pathlib.Path('/home/rah/sglang-V100')
service='sglang-qwen38-8082.service'
image='geesegeesegeese/sglang-v100:v100-qwen38-flash-next-v5'
container='qwen38-v5-validation'
url='http://127.0.0.1:8083'
state={'stage':'preparing_container_validation','restore_required':False}
env=os.environ.copy()
env.update(QWEN38_IMAGE=image,QWEN38_CONTAINER=container,PORT='8083',
           QWEN38_JIT_VOLUME='qwen38-v5-jit',HF_HUB_OFFLINE='1')
env.pop('HF_TOKEN',None)  # Cached public checkpoint needs no credential during validation.

def save(**kwargs):
    state.update(kwargs)
    (root/'validation_state.json').write_text(json.dumps(state,indent=2)+'\n')
    print(state,flush=True)

def command(args,timeout=120,**kwargs):
    return subprocess.run(args,check=True,timeout=timeout,**kwargs)

def job(label,args,timeout=900,allow_failure=False):
    save(job=label)
    with (root/(label+'.log')).open('x') as log:
        result=subprocess.run(args,cwd=repo,stdout=log,stderr=subprocess.STDOUT,timeout=timeout)
    if result.returncode and not allow_failure:
        raise RuntimeError(label+' failed; see its log')
    return result.returncode

def ready(endpoint,docker=False):
    deadline=time.monotonic()+1800
    while time.monotonic()<deadline:
        if docker:
            status=json.loads(subprocess.check_output(['docker','inspect',container],text=True))[0]
            if status['RestartCount'] or not status['State']['Running']:
                raise RuntimeError('Docker stopped/restarted during startup')
        try:
            if requests.get(endpoint+'/health',timeout=2).ok:return
        except requests.RequestException:pass
        time.sleep(4)
    raise TimeoutError('Model readiness timeout: '+endpoint)

assert not subprocess.check_output(['git','status','--porcelain'],cwd=repo,text=True).strip()
assert subprocess.run(['docker','container','inspect',container],capture_output=True).returncode != 0
image_info=json.loads(subprocess.check_output(['docker','image','inspect',image],text=True))[0]
revision=image_info['Config']['Labels']['org.opencontainers.image.revision']
assert revision==subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip(),revision
(root/'tested_image.json').write_text(json.dumps({'id':image_info['Id'],'revision':revision,'image':image},indent=2)+'\n')
try:
    save(stage='measuring_host')
    job('host_text',[sys.executable,'benchmark/qwen38_spec/throughput.py','run','--url','http://127.0.0.1:8082','--corpus','/home/rah/qwen38-runs/20261104-throughput/corpus.json','--case','prose_1000','--requests','8','--output-tokens','1024','--concurrency','1','4','8','--repeats','1','--label','host_default','--output',str(root/'host_text')],timeout=900)
    save(stage='stopping_host',restore_required=True)
    command(['systemctl','--user','stop',service])
    # Numerical tests use only the image's installed runtime and libraries.
    job('container_native_tests',['docker','run','--rm','--gpus','all','--ipc','host',
        '--env','CUDA_VISIBLE_DEVICES=0','--volume',str(repo/'test/manual/layers')+':/tests:ro',
        '--entrypoint','python','sglang-v100:qwen38-v5-tests','-m','pytest','-q',
        '/tests/test_sm70_grouped_qsa.py','/tests/test_sm70_vision_attention.py'],timeout=900)
    volume=subprocess.run(['docker','volume','inspect','qwen38-v5-jit'],capture_output=True,text=True)
    (root/'jit_volume_before.json').write_text(volume.stdout if volume.returncode==0 else '{"existed":false}\n')
    save(stage='starting_container')
    command(['bash','scripts/qwen38.sh','start'],cwd=repo,env=env)
    save(stage='container_loading')
    ready(url,docker=True)
    info=requests.get(url+'/server_info',timeout=20).json()
    expected={'speculative_num_steps':3,'speculative_num_draft_tokens':4,
              'max_running_requests':8,'context_length':262144,'max_total_tokens':277280,
              'max_mamba_cache_size':48,'chunked_prefill_size':2048,'mm_attention_backend':'fa2_v100',
              'speculative_adaptive':False}
    for key,value in expected.items():assert info[key]==value,(key,info[key])
    assert info['internal_states'][0]['effective_max_running_requests_per_dp']==8
    variables=dict(x.split(b'=',1) for x in subprocess.check_output(['docker','exec',container,'cat','/proc/1/environ']).split(b'\0') if b'=' in x)
    selected={}
    for key in ['SGLANG_SM70_MTP_LOCAL_TOP1','SGLANG_SM70_HC_COMBINE_NORM','SGLANG_SM70_AR_PUSH16']:
        selected[key]=variables.get(key.encode(),b'0').decode();assert selected[key]=='0',key
    for key in ['SGLANG_MM_PREPROCESS_ON_CPU','SGLANG_SM70_BATCHED_MOE','SGLANG_SM70_BATCHED_MOE32','SGLANG_SM70_BATCHED_FUSIONS']:
        selected[key]=variables.get(key.encode(),b'0').decode();assert selected[key]=='1',key
    (root/'container_server.json').write_text(json.dumps(info,indent=2)+'\n')
    (root/'container_profile_flags.json').write_text(json.dumps(selected,indent=2)+'\n')
    save(stage='checking_container')
    job('container_checks',[sys.executable,'benchmark/qwen38_spec/check.py','--url',url,'--full-context','--output',str(root/'container_checks.json')])
    job('container_tools',[sys.executable,'benchmark/qwen38_spec/check_tools.py','--url',url,'--output',str(root/'container_tools.json')])
    job('container_shared',[sys.executable,'benchmark/qwen38_spec/check_shared_document.py','--url',url,'--concurrency','8','--output',str(root/'container_shared.json')])
    job('container_mm',[sys.executable,'benchmark/qwen38_nvfp4_v100_multimodal_20260909/validate.py','--base-url',url,'--tag','container_mm','--output-dir',str(root)],allow_failure=True)
    mm=json.loads((root/'container_mm_results.json').read_text())
    failures=[c for c in mm['cases'] if not c['passed']]
    assert len(mm['cases'])==12 and mm['health_status']==200
    assert not failures or len(failures)==1 and failures[0]['name']=='ocr' and failures[0]['text'].strip()=='V10 CHECK 4827',failures
    job('container_images',[sys.executable,'benchmark/qwen38_vision_v100_20261104/image_bench.py','--url',url,'--output',str(root/'container_images'),'--repeats','1','--label','docker_v5'])
    job('container_queue',[sys.executable,'benchmark/qwen38_spec/check_queue.py','--url',url,'--output-dir',str(root/'container_queue'),'--lengths','4097','8191','12289','16387','20003','24007','28001','32003'],timeout=1200)
    save(stage='measuring_container')
    for label,case,tokens,cs,repeats,speed in [
        ('container_text','prose_1000',1024,[1,4,8],2,False),
        ('container_speed','speed',512,[8],1,True)]:
        corpus='/home/rah/qwen38-runs/20261104-throughput/'+('speed_agents.json' if speed else 'corpus.json')
        job(label,[sys.executable,'benchmark/qwen38_spec/throughput.py','run','--url',url,
                   '--corpus',corpus,'--case',case,'--requests','20' if speed else '8',
                   '--output-tokens',str(tokens),'--concurrency',*map(str,cs),
                   '--repeats',str(repeats),'--label',label,'--output',str(root/label),
                   *(['--natural-eos'] if speed else [])],timeout=1200)
    assert requests.get(url+'/health',timeout=10).status_code==200
    (root/'container_validation.done').write_text('Default-profile container checks passed\n')
    save(stage='container_passed',passed=True)
except BaseException as error:
    save(error=repr(error),passed=False)
    raise
finally:
    if subprocess.run(['docker','container','inspect',container],capture_output=True).returncode==0:
        with (root/'container_server.log').open('w') as log:
            subprocess.run(['docker','logs',container],stdout=log,stderr=subprocess.STDOUT)
        subprocess.run(['docker','stop','--time','60',container],timeout=90)
        inspected=json.loads(subprocess.check_output(['docker','inspect',container],text=True))[0]
        inspected['Config']['Env']=[v for v in inspected['Config'].get('Env',[]) if not any(word in v.split('=',1)[0].upper() for word in ['TOKEN','SECRET','PASSWORD','API_KEY'])]
        (root/'container_inspect.json').write_text(json.dumps(inspected,indent=2)+'\n')
        # This is the test container created above; both cache volumes remain.
        command(['docker','rm',container])
    save(stage='restoring_host')
    command(['systemctl','--user','start',service])
    ready('http://127.0.0.1:8082')
    save(stage='host_restored',restore_required=False)
    if state.get('passed'):
        job('host_live',[sys.executable,str(root/'check_host_live.py')],timeout=600)
        save(stage='complete',restore_required=False)
        (root/'validation.done').write_text('Container passed and default host restored\n')

