import json
import pathlib
import subprocess
import sys
import time

root = pathlib.Path(__file__).resolve().parent
repo = pathlib.Path('/home/rah/sglang-V100')
image = 'geesegeesegeese/sglang-v100:v100-qwen38-flash-next-v5'
test_image = 'sglang-v100:qwen38-v5-tests'
revision = '7e280c7ce3e99efd6d98882f4aba378c3ec7f052'
deadline = time.monotonic() + 3600
while time.monotonic() < deadline:
    result = subprocess.run(['docker','image','inspect',image],capture_output=True,text=True)
    if result.returncode == 0:
        data = json.loads(result.stdout)[0]
        if data['Config']['Labels'].get('org.opencontainers.image.revision') == revision:
            break
    time.sleep(3)
else:
    raise TimeoutError('Release image did not finish building')

print('Release image built; preparing isolated pytest layer',flush=True)
with (root/'build_tests.log').open('x') as log:
    subprocess.run(['docker','build','--network=host','-t',test_image,'-'],
                   input=(root/'Dockerfile.tests').read_text(),text=True,
                   stdout=log,stderr=subprocess.STDOUT,check=True,timeout=600)
tested = json.loads(subprocess.check_output(['docker','image','inspect',test_image],text=True))[0]
assert tested['RootFS']['Layers'][:len(data['RootFS']['Layers'])] == data['RootFS']['Layers']
probe = 'import json,torch,pytest,flash_attn_v100; from sglang.srt.layers.attention.tilelang_fa_v100._grouped_qsa import load_grouped_qsa_ops; print(json.dumps(dict(torch=torch.__version__,cuda=torch.version.cuda,pytest=pytest.__version__,masked_qsa=load_grouped_qsa_ops().sglang_masked_sparse_kv)))'
checked = subprocess.check_output(['docker','run','--rm','--entrypoint','python',test_image,'-c',probe],text=True)
(root/'image_cpu_checks.json').write_text(checked)
(root/'image_manifest.json').write_text(json.dumps({'image':image,'id':data['Id'],'source_revision':revision,'layers':data['RootFS']['Layers'],'tests_image':test_image,'tests_id':tested['Id']},indent=2)+'\n')
print('CPU image checks passed; starting host control and Docker GPU validation',flush=True)
with (root/'validate_container.log').open('x') as log:
    subprocess.run([sys.executable,str(root/'validate_container.py')],cwd=repo,
                   stdout=log,stderr=subprocess.STDOUT,check=True)
print('Docker validated and balanced host restored',flush=True)
