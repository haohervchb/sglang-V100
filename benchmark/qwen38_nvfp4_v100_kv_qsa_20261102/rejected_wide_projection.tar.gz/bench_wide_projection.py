import json
from pathlib import Path
import statistics

import torch
from sglang.jit_kernel.sm70_small_gemm import _CONFIGS
from sglang.jit_kernel.utils import load_jit

root = Path(__file__).parent
torch.manual_seed(512)
results = []
for (original_rows, n, k), (threads, lanes) in _CONFIGS.items():
    if original_rows != 4 or n == 16384:
        continue
    rows = 8
    x = torch.randn(rows, k, device='cuda', dtype=torch.float16)
    weight = torch.randn(n, k, device='cuda', dtype=torch.float16) * .01
    outputs = {name: torch.empty(rows,n,device='cuda',dtype=torch.float16) for name in ['torch','native']}
    mod = load_jit('sm70_small_gemm_wide_experiment',rows,threads,lanes,
        cuda_files=[str(root/'sm70_small_gemm_wide.cuh')],
        cuda_wrappers=[('run',f'sglang::sm70_small_gemm::run<{rows},{threads},{lanes}>')])
    calls = {'torch':lambda:torch.mm(x,weight.T,out=outputs['torch']),
             'native':lambda:mod.run(x,weight,outputs['native'])}
    reference=(x.float()@weight.float().T).half()
    graphs={}
    errors={}
    for name,call in calls.items():
        call()
        errors[name]=float((outputs[name].float()-reference.float()).norm()/reference.float().norm())
        if name=='native':
            torch.testing.assert_close(outputs[name],reference,rtol=.003,atol=.001)
        graph=torch.cuda.CUDAGraph()
        with torch.cuda.graph(graph):
            for _ in range(10):call()
        graphs[name]=graph
    for _ in range(150):
        for graph in graphs.values():graph.replay()
    torch.cuda.synchronize()
    times={name:[] for name in calls}
    for repeat in range(12):
        for name in list(calls) if repeat%2==0 else reversed(calls):
            start,end=torch.cuda.Event(enable_timing=True),torch.cuda.Event(enable_timing=True)
            start.record();graphs[name].replay();end.record();end.synchronize()
            times[name].append(start.elapsed_time(end)/10)
    row=dict(rows=rows,n=n,k=k,threads=threads,lanes=lanes,samples_ms=times,relative_l2_to_fp32=errors,
        median_ms={name:statistics.median(v) for name,v in times.items()})
    row['speedup']=row['median_ms']['torch']/row['median_ms']['native']
    results.append(row)
    print(json.dumps(row),flush=True)
    (root/'wide_projection_micro.json').write_text(json.dumps(results,indent=2))
