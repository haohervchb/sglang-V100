import json
import statistics
from pathlib import Path

import torch
import sglang.srt.layers.hyperconnection as hc
from sglang.jit_kernel.utils import load_jit

root = Path(__file__).parent
torch.manual_seed(721)
results = []
with torch.inference_mode():
    for rows in [6, 8]:
        layer = hc.GatedResidual(hc.HyperConnectionConfig(hc_count=4, hidden_size=2560, hc_lowrank=320, params_dtype=torch.float16, hc_per_branch_norm=True)).cuda().half()
        layer.input_mix_weight_down.weight.normal_(std=.01)
        layer.input_mix_weight_up.weight.normal_(std=.01)
        x = torch.randn(rows, 10240, device='cuda', dtype=torch.float16)
        mod = load_jit('sm70_hc_wide_experiment', rows, cuda_files=[str(root/'sm70_hc_batch_wide.cuh')],
            cuda_wrappers=[('down', f'sglang::sm70_hc_batch::down_run<{rows}>'), ('up', f'sglang::sm70_hc_batch::up_run<{rows}>')], extra_cuda_cflags=['--fmad=false'])
        def down(x, w, count):
            out = torch.empty(rows, 320, device=x.device, dtype=x.dtype)
            mod.down(x, w, out)
            return out
        def up(a, x, w, count, hidden):
            out = torch.empty(rows, 2560, device=x.device, dtype=x.dtype)
            mod.up(a, x, w, out)
            return out
        original = hc.sm70_hc_down_gemv_silu_supported, hc.sm70_hc_down_gemv_silu, hc.sm70_hc_up_gemv_reduce
        graphs, outputs = {}, {}
        try:
            for label in ['existing', 'native']:
                if label == 'native':
                    hc.sm70_hc_down_gemv_silu_supported = lambda *args: True
                    hc.sm70_hc_down_gemv_silu, hc.sm70_hc_up_gemv_reduce = down, up
                for _ in range(3):
                    layer.mix(x)
                graph = torch.cuda.CUDAGraph()
                with torch.cuda.graph(graph):
                    for _ in range(10):
                        out = layer.mix(x)[0]
                graphs[label], outputs[label] = graph, out
        finally:
            hc.sm70_hc_down_gemv_silu_supported, hc.sm70_hc_down_gemv_silu, hc.sm70_hc_up_gemv_reduce = original
        for graph in graphs.values():
            graph.replay()
        torch.cuda.synchronize()
        normed = layer.hc_norm(x)
        projected = (normed.float() @ layer.input_mix_weight_down.weight.float().T).half().float() / 4
        activated = torch.nn.functional.silu(projected).half()
        u = (activated.float() @ layer.input_mix_weight_up.weight.float().T).half().float()
        reference = (u.sigmoid()*normed.float()).view(rows, 4, 2560).mean(1).half()
        torch.testing.assert_close(outputs['native'], reference, atol=.0003, rtol=.002)
        relative = float((outputs['native'].float()-outputs['existing'].float()).norm()/outputs['existing'].float().norm())
        assert relative < .002
        for _ in range(200):
            for graph in graphs.values():
                graph.replay()
        torch.cuda.synchronize()
        times = {key: [] for key in graphs}
        for repeat in range(12):
            for name in list(graphs) if repeat % 2 == 0 else reversed(graphs):
                start, end = torch.cuda.Event(enable_timing=True), torch.cuda.Event(enable_timing=True)
                start.record()
                graphs[name].replay()
                end.record()
                end.synchronize()
                times[name].append(start.elapsed_time(end)/10)
        results.append(dict(rows=rows, relative_l2=relative, median_ms={key: statistics.median(values) for key, values in times.items()}, samples_ms=times))
        print(json.dumps(results[-1]), flush=True)
        (root/'wide_hc_micro.json').write_text(json.dumps(results, indent=2))
