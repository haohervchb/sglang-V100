"""Interleaved SM70 QSA kernel measurements; includes grouped planner cost."""

import argparse
import json
import statistics
from pathlib import Path

import torch
from sglang.jit_kernel.sm70_qsa_grouped_prefill import grouped_prefill
from sglang.srt.layers.attention.tilelang_fa_v100._decode_cuda import (
    sm70_cuda_qsa_prefill,
)


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--output", required=True)
    p.add_argument("--repeats", type=int, default=8)
    args = p.parse_args()
    results = []
    for rows in [256, 1024, 8192]:
        for dtype in [torch.float8_e5m2, torch.float16]:
            for shared in [384, 512]:
                torch.manual_seed(41)
                length = 70000 + rows
                q = torch.randn(rows, 6, 256, device="cuda", dtype=torch.float16)
                k = torch.randn(length, 1, 256, device="cuda").to(dtype)
                v = torch.randn_like(k.float()).to(dtype)
                table = (
                    (
                        torch.randperm(length // 4, device="cuda", dtype=torch.int32)[
                            :, None
                        ]
                        * 4
                        + torch.arange(4, device="cuda")
                    )
                    .flatten()[None]
                    .int()
                )
                request = torch.zeros(1, device="cuda", dtype=torch.int32)
                lens = torch.tensor([length], device="cuda", dtype=torch.int32)
                common = torch.arange(shared, device="cuda").expand(rows, -1)
                tail = (
                    shared
                    + torch.arange(512 - shared, device="cuda")[None]
                    + torch.arange(rows, device="cuda")[:, None] % 8 * (512 - shared)
                )
                blocks = torch.cat([common, tail], dim=1)
                indices = torch.full((rows, 2051), -1, device="cuda", dtype=torch.int32)
                indices[:, :2048] = (
                    blocks[:, :, None] * 4 + torch.arange(4, device="cuda")
                ).reshape(rows, -1)
                calls = {"row": sm70_cuda_qsa_prefill, "grouped": grouped_prefill}

                def run(label):
                    return calls[label](q, k, v, table, request, indices, lens, 0.0625)

                outputs = {label: run(label) for label in calls}
                torch.testing.assert_close(
                    outputs["row"], outputs["grouped"], atol=0.001, rtol=0.008
                )
                for _ in range(3):
                    for label in calls:
                        run(label)
                times = {label: [] for label in calls}
                for rep in range(args.repeats):
                    for label in list(calls) if rep % 2 == 0 else list(reversed(calls)):
                        start, end = (
                            torch.cuda.Event(enable_timing=True),
                            torch.cuda.Event(enable_timing=True),
                        )
                        start.record()
                        run(label)
                        end.record()
                        end.synchronize()
                        times[label].append(start.elapsed_time(end))
                row = dict(
                    rows=rows,
                    dtype=str(dtype),
                    shared_blocks=shared,
                    samples_ms=times,
                    median_ms={
                        key: statistics.median(vals) for key, vals in times.items()
                    },
                )
                row["speedup"] = row["median_ms"]["row"] / row["median_ms"]["grouped"]
                results.append(row)
                print(json.dumps(row), flush=True)
                Path(args.output).write_text(json.dumps(results, indent=2))


if __name__ == "__main__":
    main()
