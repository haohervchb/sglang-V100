# SPDX-License-Identifier: Apache-2.0
"""Experimental grouped QSA prefill inspired by 1CatAI/1Cat-vLLM#387."""

from functools import lru_cache
from pathlib import Path

import torch


@lru_cache(maxsize=1)
def _module():
    from torch.utils.cpp_extension import load

    return load(
        name="sglang_sm70_qsa_grouped_prefill",
        sources=[str(Path(__file__).parent / "csrc/sm70_qsa_grouped_prefill.cu")],
        extra_cuda_cflags=["-O3", "--expt-relaxed-constexpr"],
        verbose=False,
    )


def grouped_prefill(q, k, v, table, requests, indices, lengths, scale):
    from sglang.srt.layers.attention.tilelang_fa_v100._decode_cuda import (
        _qsa_cache_view,
    )

    groups = (q.shape[0] + 7) // 8
    pages = torch.empty((groups, 8192), device=q.device, dtype=torch.int32)
    masks = torch.empty_like(pages)
    counts = torch.empty((groups,), device=q.device, dtype=torch.int32)
    out = torch.empty_like(q)
    _module().grouped_prefill(
        q.contiguous(),
        _qsa_cache_view(k),
        _qsa_cache_view(v),
        table.int().contiguous(),
        requests.int().contiguous(),
        indices.int().contiguous(),
        lengths.int().contiguous(),
        pages,
        masks,
        counts,
        out,
        float(scale),
    )
    return out
