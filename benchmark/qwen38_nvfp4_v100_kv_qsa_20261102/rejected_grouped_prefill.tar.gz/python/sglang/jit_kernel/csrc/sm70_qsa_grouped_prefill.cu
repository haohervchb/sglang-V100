// SPDX-License-Identifier: Apache-2.0
// Experimental SM70 QSA prefill. The eight-query / Page4 visibility-mask
// design follows 1CatAI/1Cat-vLLM#387. This implementation uses SGLang's token
// pool, deterministic sorted page plans, and standard CUDA WMMA.
#include <ATen/cuda/CUDAContext.h>
#include <c10/cuda/CUDAGuard.h>
#include <c10/cuda/CUDAException.h>
#include <cuda_fp16.h>
#include <mma.h>
#include <cub/block/block_radix_sort.cuh>
#include <torch/extension.h>

namespace {
constexpr int Threads = 256;
constexpr int Capacity = 8192;
constexpr int Queries = 8;
constexpr int Heads = 6;
constexpr int Dim = 256;
constexpr int QStride = 264, KVStride = 264, OStride = 264, SStride = 40;
constexpr unsigned long long Empty = 0x00000000ffffffffULL;
using Sort = cub::BlockRadixSort<unsigned, Threads, Capacity / Threads, unsigned>;
constexpr size_t PlanBytes = sizeof(Sort::TempStorage) > Capacity * 8
    ? sizeof(Sort::TempStorage) : Capacity * 8;
static_assert(PlanBytes <= 96 * 1024 - 16, "Planner exceeds SM70 shared memory");

__global__ void plan(const int* indices, const int* table, const int* request,
                     const int* lengths, int* pages, unsigned* masks, int* counts,
                     int rows, int topk, int stride) {
  extern __shared__ __align__(16) unsigned char storage[];
  auto* hash = reinterpret_cast<unsigned long long*>(storage);
  __shared__ int fallback;
  int tid = threadIdx.x, group = blockIdx.x;
  if (tid == 0) { fallback = 0; counts[group] = 0; }
  for (int i = tid; i < Capacity; i += Threads) hash[i] = Empty;
  __syncthreads();
  const int seq_len = lengths[0], req = request[0];
  for (int i = tid; i < Queries * topk; i += Threads) {
    if (atomicAdd(&fallback, 0)) break;
    int query = i / topk, col = i % topk, row = group * Queries + query;
    int visible = seq_len - rows + row + 1;
    if (row >= rows || col >= min(topk, visible)) continue;
    int logical = indices[row * topk + col];
    if (logical < 0 || logical >= visible || logical >= seq_len) continue;
    int physical = table[(int64_t)req * stride + logical];
    if (physical < 0) continue;
    unsigned page = physical >> 2;
    unsigned mask = 1u << (query * 4 + (physical & 3));
    unsigned slot = (page * 2654435761u) & (Capacity - 1);
    unsigned long long wanted = (static_cast<unsigned long long>(mask) << 32) | page;
    bool inserted = false;
    for (int probe = 0; probe < 128; ++probe) {
      auto old = atomicCAS(hash + slot, Empty, wanted);
      if (old == Empty) { inserted = true; break; }
      if (static_cast<unsigned>(old) == page) {
        old = atomicOr(hash + slot, static_cast<unsigned long long>(mask) << 32);
        // Duplicated selections must retain their multiplicity. The fallback
        // computes the original selection lists instead of a set union.
        if ((static_cast<unsigned>(old >> 32) & mask) != 0) atomicExch(&fallback, 1);
        inserted = true;
        break;
      }
      slot = (slot + 1) & (Capacity - 1);
    }
    if (!inserted) atomicExch(&fallback, 1);
  }
  __syncthreads();
  if (fallback) { if (tid == 0) counts[group] = -1; return; }
  unsigned keys[Capacity / Threads], values[Capacity / Threads];
#pragma unroll
  for (int i = 0; i < Capacity / Threads; ++i) {
    auto entry = hash[tid * (Capacity / Threads) + i];
    keys[i] = static_cast<unsigned>(entry);
    values[i] = static_cast<unsigned>(entry >> 32);
  }
  __syncthreads();
  auto& temp = *reinterpret_cast<Sort::TempStorage*>(storage);
  Sort(temp).Sort(keys, values);
  int valid_count = 0;
#pragma unroll
  for (int i = 0; i < Capacity / Threads; ++i) {
    int pos = tid * (Capacity / Threads) + i;
    if (keys[i] != 0xffffffffu) {
      pages[(int64_t)group * Capacity + pos] = keys[i];
      masks[(int64_t)group * Capacity + pos] = values[i];
      ++valid_count;
    }
  }
  atomicAdd(counts + group, valid_count);
}

template<typename KV> __device__ __forceinline__ half read_kv(const KV* ptr, int64_t i) {
  if constexpr (sizeof(KV) == 1) return __ushort_as_half(static_cast<unsigned short>(ptr[i]) << 8);
  else return ptr[i];
}

// Two CTAs per group, each owning three heads for all eight queries. Padding
// 24 rows to 32 allows Volta 16x16 WMMA while staying below 96 KiB shared RAM.
struct __align__(32) AttentionStorage {
  half q[32 * QStride];
  half kv[32 * KVStride];
  float out[32 * OStride];
  float scores[32 * SStride];
  half probabilities[32 * SStride];
  float maxima[32], sums[32], alpha[32];
  int slots[32];
  unsigned visible[32];
};
static_assert(sizeof(AttentionStorage) <= 96 * 1024, "Attention exceeds SM70 shared memory");

template<typename KV>
__global__ void attend(const half* q, const KV* k, const KV* v,
                       const int* pages, const unsigned* masks, const int* counts,
                       const int* indices, const int* table, const int* request,
                       const int* lengths, half* out,
                       int rows, int topk, int stride, float scale, int pool_size) {
  using namespace nvcuda;
  extern __shared__ __align__(32) unsigned char storage[];
  auto& s = *reinterpret_cast<AttentionStorage*>(storage);
  int tid = threadIdx.x, warp = tid / 32, lane = tid % 32;
  int group = blockIdx.x, head_start = blockIdx.y * 3;
  int count = counts[group], seq_len = lengths[0], req = request[0];
  bool fallback = count < 0;
  int total = fallback ? Queries * topk : count * 4;
  for (int i = tid; i < 32 * Dim; i += Threads) {
    int r = i / Dim, d = i % Dim, row = group * Queries + r / 3;
    s.q[r * QStride + d] = r < 24 && row < rows ? q[((int64_t)row * Heads + head_start + r % 3) * Dim + d] : __float2half(0.f);
    s.out[r * OStride + d] = 0.f;
  }
  if (tid < 32) { s.maxima[tid] = -INFINITY; s.sums[tid] = 0.f; }
  __syncthreads();
  for (int tile = 0; tile < total; tile += 32) {
    if (tid < 32) {
      int token = tile + tid, slot = -1;
      unsigned visibility = 0;
      if (token < total) {
        if (!fallback) {
          slot = pages[(int64_t)group * Capacity + token / 4] * 4 + token % 4;
          unsigned mask = masks[(int64_t)group * Capacity + token / 4];
          for (int query = 0; query < Queries; ++query)
            if (mask & (1u << (query * 4 + token % 4))) visibility |= 1u << query;
        } else {
          int query = token / topk, col = token % topk, row = group * Queries + query;
          int visible = seq_len - rows + row + 1;
          if (row < rows && col < min(topk, visible)) {
            int logical = indices[row * topk + col];
            if (logical >= 0 && logical < visible && logical < seq_len) {
              slot = table[(int64_t)req * stride + logical];
              visibility = 1u << query;
            }
          }
        }
      }
      s.slots[tid] = slot;
      s.visible[tid] = visibility;
    }
    __syncthreads();
    for (int i = tid; i < 32 * Dim; i += Threads) {
      int slot = s.slots[i / Dim];
      s.kv[(i / Dim) * KVStride + i % Dim] = slot >= 0 && slot < pool_size ? read_kv(k, (int64_t)slot * Dim + i % Dim) : __float2half(0.f);
    }
    __syncthreads();
    if (warp < 4) {
      wmma::fragment<wmma::matrix_a, 16, 16, 16, half, wmma::row_major> a;
      wmma::fragment<wmma::matrix_b, 16, 16, 16, half, wmma::col_major> b;
      wmma::fragment<wmma::accumulator, 16, 16, 16, float> c;
      wmma::fill_fragment(c, 0.f);
      int m = warp / 2, n = warp % 2;
      for (int d = 0; d < Dim; d += 16) {
        wmma::load_matrix_sync(a, s.q + m * 16 * QStride + d, QStride);
        wmma::load_matrix_sync(b, s.kv + n * 16 * KVStride + d, KVStride);
        wmma::mma_sync(c, a, b, c);
      }
      wmma::store_matrix_sync(s.scores + m * 16 * SStride + n * 16, c, SStride, wmma::mem_row_major);
    }
    __syncthreads();
    for (int r = warp; r < 32; r += Threads / 32) {
      bool valid = r < 24 && (s.visible[lane] & (1u << (r / 3)));
      float score = valid ? s.scores[r * SStride + lane] * scale : -INFINITY;
      float maximum = score;
      for (int offset = 16; offset; offset /= 2) maximum = fmaxf(maximum, __shfl_xor_sync(0xffffffff, maximum, offset));
      float next_max = fmaxf(s.maxima[r], maximum);
      float alpha = isfinite(s.maxima[r]) ? expf(s.maxima[r] - next_max) : 0.f;
      float p = valid ? expf(score - next_max) : 0.f;
      s.probabilities[r * SStride + lane] = __float2half(p);
      float sum = p;
      for (int offset = 16; offset; offset /= 2) sum += __shfl_xor_sync(0xffffffff, sum, offset);
      if (lane == 0) { s.maxima[r] = next_max; s.sums[r] = s.sums[r] * alpha + sum; s.alpha[r] = alpha; }
    }
    __syncthreads();
    for (int i = tid; i < 32 * Dim; i += Threads) {
      s.out[(i / Dim) * OStride + i % Dim] *= s.alpha[i / Dim];
      int slot = s.slots[i / Dim];
      s.kv[(i / Dim) * KVStride + i % Dim] = slot >= 0 && slot < pool_size ? read_kv(v, (int64_t)slot * Dim + i % Dim) : __float2half(0.f);
    }
    __syncthreads();
    for (int tile_id = warp; tile_id < 32; tile_id += Threads / 32) {
      int m = tile_id / 16, n = tile_id % 16;
      wmma::fragment<wmma::matrix_a, 16, 16, 16, half, wmma::row_major> a;
      wmma::fragment<wmma::matrix_b, 16, 16, 16, half, wmma::row_major> b;
      wmma::fragment<wmma::accumulator, 16, 16, 16, float> c;
      wmma::load_matrix_sync(c, s.out + m * 16 * OStride + n * 16, OStride, wmma::mem_row_major);
      for (int d = 0; d < 32; d += 16) {
        wmma::load_matrix_sync(a, s.probabilities + m * 16 * SStride + d, SStride);
        wmma::load_matrix_sync(b, s.kv + d * KVStride + n * 16, KVStride);
        wmma::mma_sync(c, a, b, c);
      }
      wmma::store_matrix_sync(s.out + m * 16 * OStride + n * 16, c, OStride, wmma::mem_row_major);
    }
    __syncthreads();
  }
  for (int i = tid; i < 24 * Dim; i += Threads) {
    int r = i / Dim, row = group * Queries + r / 3;
    if (row < rows) out[((int64_t)row * Heads + head_start + r % 3) * Dim + i % Dim] =
        __float2half(s.sums[r] > 0.f ? s.out[r * OStride + i % Dim] / s.sums[r] : 0.f);
  }
}

template<typename KV> void launch_attention(torch::Tensor q, torch::Tensor k, torch::Tensor v,
    torch::Tensor pages, torch::Tensor masks, torch::Tensor counts,
    torch::Tensor indices, torch::Tensor table, torch::Tensor request, torch::Tensor lengths,
    torch::Tensor out, double scale) {
  C10_CUDA_CHECK(cudaFuncSetAttribute(attend<KV>, cudaFuncAttributeMaxDynamicSharedMemorySize, sizeof(AttentionStorage)));
  attend<KV><<<dim3(counts.numel(), 2), Threads, sizeof(AttentionStorage), at::cuda::getCurrentCUDAStream()>>>(
    reinterpret_cast<const half*>(q.data_ptr()), reinterpret_cast<const KV*>(k.data_ptr()), reinterpret_cast<const KV*>(v.data_ptr()),
    pages.data_ptr<int>(), reinterpret_cast<unsigned*>(masks.data_ptr()), counts.data_ptr<int>(), indices.data_ptr<int>(),
    table.data_ptr<int>(), request.data_ptr<int>(), lengths.data_ptr<int>(), reinterpret_cast<half*>(out.data_ptr()),
    q.size(0), indices.size(1), table.size(1), scale, k.size(0));
  C10_CUDA_KERNEL_LAUNCH_CHECK();
}
}  // namespace

void grouped_prefill(torch::Tensor q, torch::Tensor k, torch::Tensor v,
    torch::Tensor table, torch::Tensor request, torch::Tensor indices, torch::Tensor lengths,
    torch::Tensor pages, torch::Tensor masks, torch::Tensor counts, torch::Tensor out, double scale) {
  c10::cuda::CUDAGuard guard(q.device());
  TORCH_CHECK(q.is_cuda() && q.scalar_type() == torch::kHalf && q.dim() == 3 && q.size(1) == Heads && q.size(2) == Dim, "Expected CUDA FP16 Q [rows,6,256]");
  TORCH_CHECK((k.scalar_type() == torch::kHalf || k.scalar_type() == torch::kUInt8) && v.scalar_type() == k.scalar_type() && k.dim() == 3 && k.size(1) == 1 && k.size(2) == Dim && v.sizes() == k.sizes(), "Expected FP16 or E5M2 byte cache");
  TORCH_CHECK(indices.scalar_type() == torch::kInt && indices.dim() == 2 && indices.size(0) == q.size(0) && indices.size(1) > 0, "Invalid selection indices");
  TORCH_CHECK(request.numel() == 1 && lengths.numel() == 1 && table.dim() == 2 && request.scalar_type() == torch::kInt && lengths.scalar_type() == torch::kInt && table.scalar_type() == torch::kInt, "Expected single-request int32 metadata");
  int groups = (q.size(0) + Queries - 1) / Queries;
  TORCH_CHECK(pages.dim() == 2 && pages.size(0) == groups && pages.size(1) == Capacity && masks.sizes() == pages.sizes() && counts.numel() == groups && pages.scalar_type() == torch::kInt && masks.scalar_type() == torch::kInt && counts.scalar_type() == torch::kInt && out.sizes() == q.sizes() && out.scalar_type() == torch::kHalf, "Invalid scratch/output buffers");
  for (auto t : {q,k,v,table,request,indices,lengths,pages,masks,counts,out}) TORCH_CHECK(t.device() == q.device() && t.is_contiguous(), "Expected contiguous tensors on one device");
  C10_CUDA_CHECK(cudaFuncSetAttribute(plan, cudaFuncAttributeMaxDynamicSharedMemorySize, PlanBytes));
  plan<<<groups, Threads, PlanBytes, at::cuda::getCurrentCUDAStream()>>>(indices.data_ptr<int>(), table.data_ptr<int>(), request.data_ptr<int>(), lengths.data_ptr<int>(), pages.data_ptr<int>(), reinterpret_cast<unsigned*>(masks.data_ptr()), counts.data_ptr<int>(), q.size(0), indices.size(1), table.size(1));
  C10_CUDA_KERNEL_LAUNCH_CHECK();
  if (k.scalar_type() == torch::kHalf) launch_attention<half>(q,k,v,pages,masks,counts,indices,table,request,lengths,out,scale);
  else launch_attention<uint8_t>(q,k,v,pages,masks,counts,indices,table,request,lengths,out,scale);
}
PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) { m.def("grouped_prefill", &grouped_prefill); }
