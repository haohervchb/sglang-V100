import pytest
import torch

pytestmark = pytest.mark.skipif(
    not torch.cuda.is_available() or torch.cuda.get_device_capability() != (7, 0),
    reason="Grouped QSA requires V100",
)


@pytest.mark.parametrize("kv_dtype", [torch.float16, torch.float8_e5m2])
@pytest.mark.parametrize(
    "rows,prefix,topk,kind",
    [
        (17, 0, 31, "random"),
        (16, 70000, 2051, "blocks"),
        (9, 262000, 2063, "random"),
        (8, 25000, 2051, "duplicate"),
    ],
)
def test_masks_causality_and_fallback(rows, prefix, topk, kind, kv_dtype):
    from sglang.jit_kernel.sm70_qsa_grouped_prefill import grouped_prefill
    from sglang.srt.layers.attention.tilelang_fa_v100._decode_cuda import (
        sm70_cuda_qsa_prefill,
    )

    torch.manual_seed(812)
    length = rows + prefix
    q = torch.randn(rows, 6, 256, device="cuda", dtype=torch.float16)
    k = torch.randn(length + 4, 1, 256, device="cuda").to(kv_dtype)
    v = torch.randn_like(k.float()).to(kv_dtype)
    table = torch.randperm(length, device="cuda", dtype=torch.int32)[None]
    if kind == "blocks":
        # Shuffle pages while retaining the internal Page4 layout.
        table = (
            (
                torch.randperm(length // 4, device="cuda", dtype=torch.int32)[:, None]
                * 4
                + torch.arange(4, device="cuda")
            )
            .flatten()[None]
            .int()
        )
    req = torch.zeros(1, device="cuda", dtype=torch.int32)
    lengths = torch.tensor([length], device="cuda", dtype=torch.int32)
    indices = torch.full((rows, topk), -1, device="cuda", dtype=torch.int32)
    for row in range(rows):
        visible = prefix + row + 1
        count = min(visible, topk)
        selected = torch.randperm(visible, device="cuda")[:count]
        if kind == "blocks":
            blocks = torch.arange(512, device="cuda") * 4
            selected = torch.cat(
                [
                    (blocks[:, None] + torch.arange(4, device="cuda")).flatten(),
                    torch.arange(visible // 4 * 4, visible, device="cuda"),
                ]
            )
        elif kind == "duplicate":
            selected[1] = selected[0]
        indices[row, : len(selected)] = selected.int()
    reference = sm70_cuda_qsa_prefill(q, k, v, table, req, indices, lengths, 0.0625)
    result = grouped_prefill(q, k, v, table, req, indices, lengths, 0.0625)
    torch.testing.assert_close(result, reference, rtol=0.008, atol=0.001)
    assert (
        result.float() - reference.float()
    ).norm() / reference.float().norm() < 0.002
    repeat = grouped_prefill(q, k, v, table, req, indices, lengths, 0.0625)
    assert torch.equal(result, repeat)
