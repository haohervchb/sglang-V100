import hashlib,json,os,pathlib,shutil,subprocess,tempfile,time

root=pathlib.Path(__file__).resolve().parent
repo=pathlib.Path('/home/rah/sglang-V100')
old='geesegeesegeese/sglang-v100:v100-qwen38-flash-next-v5'
new='geesegeesegeese/sglang-v100:v100-qwen38-flash-next-v5.1'
def run(args,**kwargs):
    return subprocess.check_output(args,text=True,**kwargs)

manifest_code="""import pathlib,hashlib,json
p=pathlib.Path('/opt/sglang/python/sglang')
d={str(f.relative_to(p)):hashlib.sha256(f.read_bytes()).hexdigest() for f in p.rglob('*') if f.is_file() and '__pycache__' not in f.parts and f.suffix not in ['.pyc','.pyo']}
print(json.dumps(d,sort_keys=True))"""
manifests={}
for label,image in [('v5',old),('v5_1',new)]:
    d=json.loads(run(['docker','run','--rm','--entrypoint','python',image,'-c',manifest_code]))
    (root/(label+'_runtime_hashes.json')).write_text(json.dumps(d,indent=2)+'\n')
    manifests[label]=d
assert manifests['v5']==manifests['v5_1'],'The model runtime changed'
print('Unchanged runtime files:',len(manifests['v5']),flush=True)

with tempfile.TemporaryDirectory(prefix='qwen38-no-repo-') as directory:
    path=pathlib.Path(directory)
    recorder=path/'record-python'
    recorder.write_text("""#!/usr/bin/env python3
import os,sys,json
prefixes=('SGLANG_','PORT','KV_CACHE_DTYPE','CUDA_VISIBLE_DEVICES','NCCL_','PYTHONPATH','TORCH_CUDA_ARCH_LIST')
print(json.dumps({'argv':sys.argv[1:],'env':{k:v for k,v in os.environ.items() if k.startswith(prefixes)}},sort_keys=True))
""")
    recorder.chmod(0o755)
    configs=[]
    for image,args in [(old,['bash','/opt/sglang/scripts/serve_qwen38_flash_next_nvfp4_v100_throughput.sh']),
                       (new,['/usr/local/bin/serve-qwen38'])]:
        out=run(['docker','run','--rm','--volume',str(recorder)+':/tmp/record-python:ro',
                 '--env','SGLANG_PYTHON=/tmp/record-python',image,*args])
        configs.append(json.loads(out))
    assert configs[0]==configs[1],'Serving profile changed'
    (root/'profile_argv.json').write_text(json.dumps(configs[1],indent=2)+'\n')

    # Exactly the image-only extraction described in the README.
    extracted=run(['docker','run','--rm','--entrypoint','cat',new,'/usr/local/bin/qwen38.sh'])
    launcher=path/'qwen38.sh';launcher.write_text(extracted)
    assert extracted==(repo/'scripts/qwen38.sh').read_text()
    assert not (path/'.git').exists()
    name='qwen38-no-repo-'+str(os.getpid())
    volume=name+'-jit'
    env=os.environ.copy()
    env.update(QWEN38_IMAGE=new,QWEN38_CONTAINER=name,QWEN38_JIT_VOLUME=volume,
               HF_HOME=str(path/'model cache with spaces'),HF_HUB_OFFLINE='1',PORT='18082')
    env.pop('HF_TOKEN',None)
    try:
        # --help exits before model initialization; the server is never started.
        start=run(['bash',str(launcher),'start','--help'],cwd=path,env=env)
        assert run(['docker','wait',name]).strip()=='0'
        info=json.loads(run(['docker','inspect',name]))[0]
        assert info['HostConfig']['RestartPolicy']['Name']=='no'
        assert info['Config']['Labels']['org.sglang.qwen38.managed']=='true'
        assert info['HostConfig']['NetworkMode']=='host'
        assert info['HostConfig']['IpcMode']=='host'
        assert any(m['Source']==str(path/'model cache with spaces') and m['Destination']=='/root/.cache/huggingface' for m in info['Mounts'])
        assert 'PORT=18082' in info['Config']['Env']
        logs=run(['docker','logs',name],stderr=subprocess.STDOUT)
        assert 'usage:' in logs.lower() and '--model-path' in logs
        status=run(['bash',str(launcher),'status'],cwd=path,env=env)
        stopped=run(['bash',str(launcher),'stop'],cwd=path,env=env)
        (root/'standalone_check.json').write_text(json.dumps({
            'passed':True,'directory_had_repository':False,'arguments':'start --help; no model initialized',
            'restart_policy':info['HostConfig']['RestartPolicy']['Name'],
            'network':info['HostConfig']['NetworkMode'],'ipc':info['HostConfig']['IpcMode'],
            'cache_path_with_spaces':True,'status_output':status,'start_output':start,
            'stop_output':stopped,'model_runtime_files_unchanged':len(manifests['v5']),
            'serving_arguments_unchanged':True,
        },indent=2)+'\n')
    finally:
        subprocess.run(['docker','rm','-f',name],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
        subprocess.run(['docker','volume','rm',volume],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)

print('Image-only extraction, standalone lifecycle and profile parity passed',flush=True)

